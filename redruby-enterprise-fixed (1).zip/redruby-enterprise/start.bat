@echo off
echo ============================================
echo   RedRuby Enterprise AI Surveillance
echo ============================================
echo.

:: Kill old processes on ports
echo Clearing ports...
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":8003 "') do taskkill /PID %%a /F >nul 2>&1
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":5173 "') do taskkill /PID %%a /F >nul 2>&1
timeout /t 2 /nobreak > nul

:: Start backend
echo Starting Backend on port 8003...
start "RedRuby Backend" cmd /k "cd /d %~dp0backend && uvicorn app:app --host 127.0.0.1 --port 8003"

:: Wait for backend
timeout /t 8 /nobreak > nul

:: Start frontend
echo Starting Frontend...
start "RedRuby Frontend" cmd /k "cd /d %~dp0frontend && npm run dev"

:: Wait for frontend
timeout /t 8 /nobreak > nul

:: Open browser
start http://localhost:5173

echo.
echo RedRuby Enterprise is running!
echo Backend:   http://localhost:8003/docs
echo Frontend:  http://localhost:5173
echo.
pause
