"""
face_recognition_module.py — InsightFace employee face recognition
"""
import logging
from typing import Optional, Dict, List
import numpy as np
import config
from config import FACE_MODEL, FACE_DET_SIZE, FACE_MARGIN

logger = logging.getLogger(__name__)


class FaceRecognizer:
    def __init__(self):
        self.app = None
        self._enrolled: Dict[str, Dict] = {}
        self._load()

    def _load(self):
        try:
            from insightface.app import FaceAnalysis
            self.app = FaceAnalysis(name=FACE_MODEL, providers=["CPUExecutionProvider"])
            self.app.prepare(ctx_id=0, det_size=FACE_DET_SIZE)
            logger.info(f"InsightFace loaded: {FACE_MODEL}")
        except Exception as e:
            logger.error(f"InsightFace load failed: {e}")

    def enroll_employee(self, emp_id: str, name: str, images: List[np.ndarray]):
        if self.app is None:
            return
        embeddings = []
        for img in images:
            try:
                faces = self.app.get(img)
                if faces:
                    embeddings.append(faces[0].normed_embedding)
            except Exception as e:
                logger.warning(f"Face embed error {emp_id}: {e}")
        if embeddings:
            self._enrolled[emp_id] = {"name": name, "embeddings": embeddings}
            logger.info(f"Face enrolled {emp_id} ({name}) — {len(embeddings)} face(s)")

    def get_face_crop(self, crop: np.ndarray, margin: float = 0.35) -> Optional[np.ndarray]:
        """
        Detect a face inside a person crop and return a tight face-only
        sub-image (with a small margin so it's not just eyes/nose), instead
        of the full head-to-toe body crop. Returns None if no face is found
        (e.g. person is facing away) so the caller can fall back to the body crop.
        """
        if self.app is None:
            return None
        try:
            faces = self.app.get(crop)
        except Exception:
            return None
        if not faces:
            return None

        # Use the largest detected face (closest/most prominent one)
        face = max(faces, key=lambda f: (f.bbox[2]-f.bbox[0]) * (f.bbox[3]-f.bbox[1]))
        x1, y1, x2, y2 = face.bbox.astype(int)
        w, h = x2 - x1, y2 - y1
        if w <= 0 or h <= 0:
            return None

        mx, my = int(w * margin), int(h * margin)
        fx1 = max(0, x1 - mx)
        fy1 = max(0, y1 - my)
        fx2 = min(crop.shape[1], x2 + mx)
        fy2 = min(crop.shape[0], y2 + my)
        face_crop = crop[fy1:fy2, fx1:fx2]
        if face_crop.size == 0:
            return None
        return face_crop

    def recognize(self, crop: np.ndarray) -> Optional[Dict]:
        """Returns {employee_id, employee_name, confidence} or None if no face."""
        if self.app is None or not self._enrolled:
            return None
        try:
            faces = self.app.get(crop)
        except Exception:
            return None
        if not faces:
            return None

        query = faces[0].normed_embedding

        # Best score PER employee (not per individual reference photo) — this is
        # what lets us tell "clearly Sahana" apart from "Sahana barely beat Sherin".
        per_employee_best: Dict[str, float] = {}
        per_employee_name: Dict[str, str]   = {}
        for emp_id, data in self._enrolled.items():
            scores = [float(np.dot(query, ref)) for ref in data["embeddings"]]
            per_employee_best[emp_id] = max(scores) if scores else -1.0
            per_employee_name[emp_id] = data["name"]

        ranked = sorted(per_employee_best.items(), key=lambda kv: kv[1], reverse=True)
        best_id, best_score = ranked[0]
        runner_up_score = ranked[1][1] if len(ranked) > 1 else -1.0

        if best_score < config.FACE_CONFIDENCE:
            logger.debug(f"Face: below threshold ({best_score:.3f} < {config.FACE_CONFIDENCE}) → Unknown")
            return {"employee_id": "Unknown", "employee_name": "Unknown", "confidence": best_score}

        if runner_up_score >= 0 and (best_score - runner_up_score) < FACE_MARGIN:
            # Too close to call between two enrolled employees — don't guess.
            logger.info(f"Face: ambiguous match {best_id}={best_score:.3f} vs "
                       f"runner-up={runner_up_score:.3f} (margin {FACE_MARGIN}) → Unknown")
            return {"employee_id": "Unknown", "employee_name": "Unknown", "confidence": best_score}

        return {"employee_id": best_id, "employee_name": per_employee_name[best_id], "confidence": best_score}