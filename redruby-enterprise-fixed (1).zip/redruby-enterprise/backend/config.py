"""
config.py — Centralised configuration for RedRuby Enterprise
All tuneable knobs live here. Change once, applies everywhere.
"""
from pathlib import Path

# ── Paths ──────────────────────────────────────────────────────────────
BASE_DIR     = Path(__file__).parent
UPLOAD_DIR   = BASE_DIR / "uploads"
SNAPSHOT_DIR = BASE_DIR / "snapshots"
EMPLOYEE_DIR = BASE_DIR / "employees"
UNKNOWN_DB   = BASE_DIR / "unknowns_db.json"

# Image-analysis gets its own persistent gallery, completely isolated from
# the video pipeline's gallery (see unknown_tracker.py). This is what keeps
# "Image analysis must not depend on video processing state" true, and
# stops image uploads from polluting/duplicating video identities.
UNKNOWN_DB_IMAGES = BASE_DIR / "unknowns_db_images.json"

for d in [UPLOAD_DIR, SNAPSHOT_DIR, EMPLOYEE_DIR]:
    d.mkdir(exist_ok=True)

# ── Server ─────────────────────────────────────────────────────────────
BACKEND_HOST = "127.0.0.1"     # bind address for uvicorn
BACKEND_PORT = 8003
# Public-facing host used when building URLs returned to the frontend
# (snapshot/annotated-image links etc). Must match what the frontend's
# API/WS constants use ("localhost", see frontend/src/data/index.tsx and
# app.py's save_snapshot()) — otherwise image-analysis snapshots are
# generated with a different host than the rest of the app and can fail
# to load in the browser even though the server is reachable.
BACKEND_PUBLIC_HOST = "localhost"
BACKEND_URL  = f"http://{BACKEND_PUBLIC_HOST}:{BACKEND_PORT}"

# ── Detection ──────────────────────────────────────────────────────────
YOLO_MODEL          = "yolov8m.pt"     # upgraded from nano: yolov8m = much higher accuracy,
                                        # still real-time on CPU/GPU. Auto-downloads (~50MB) on first run.
YOLO_CONFIDENCE     = 0.45             # was 0.25 — too low, let weak/spurious boxes
                                        # (hands, reflections, motion blur) through as "person"
YOLO_CLASSES        = [0]              # 0 = person
PROCESS_EVERY_N     = 3               # process every Nth frame (lower = more accurate)

# ── Detection quality gate (filters non-person-shaped boxes, e.g. a raised
#    hand close to the camera) ────────────────────────────────────────────
MIN_BOX_HEIGHT_RATIO = 0.14           # box height must be >= this fraction of frame height
MAX_BOX_ASPECT_RATIO = 1.25           # reject boxes wider than they are tall by more than this
                                       # (a real head/shoulders crop is taller than wide; a hand
                                       #  held up to the camera tends to be squarish/wide)

# ── Track stability gate (prevents a 1-2 frame flicker/false-positive from
#    becoming a permanent "unknown person" card) ─────────────────────────
MIN_TRACK_HITS = 4                    # a track must be seen this many processed frames
                                       # before we run identification + show it on the dashboard

# ── Tracking ───────────────────────────────────────────────────────────
BYTETRACK_ACTIVATION  = 0.25
BYTETRACK_BUFFER      = 60            # frames to keep lost tracks (higher = survive occlusion)
BYTETRACK_MATCH_THRESH = 0.7
BYTETRACK_FPS         = 25

# ── Face Recognition ───────────────────────────────────────────────────
FACE_MODEL          = "buffalo_l"
FACE_DET_SIZE       = (320, 320)
FACE_CONFIDENCE     = 0.50            # cosine similarity threshold (was 0.35 — too permissive)
FACE_MARGIN         = 0.08            # best match must beat the runner-up employee by this much

# ── ReID ───────────────────────────────────────────────────────────────
REID_MODEL          = "osnet_x0_25"
REID_THRESHOLD      = 0.65            # employee body match threshold (was 0.55 — too permissive)
REID_MARGIN         = 0.06            # best match must beat the runner-up employee by this much
REID_UNKNOWN_THRESH = 0.60            # unknown person re-match threshold (slightly stricter)
REID_MAX_GALLERY    = 15              # max embeddings per unknown person
REID_MIN_CROP_SIZE  = 70             # minimum pixel dimension for reliable embedding (was 40 — too small, let hand/object crops through)

# ── Unknown Tracking ───────────────────────────────────────────────────
UPDATE_INTERVAL_FRAMES = 90          # re-broadcast known track every N frames
SNAPSHOT_QUALITY       = 92         # JPEG quality 0-100

# ── Websocket ──────────────────────────────────────────────────────────
WS_HEARTBEAT_SECS = 30