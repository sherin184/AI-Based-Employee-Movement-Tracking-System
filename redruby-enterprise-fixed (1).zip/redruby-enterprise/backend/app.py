import os
import uuid
import time
import asyncio
import logging
from datetime import datetime
from pathlib import Path
from typing import List

import cv2
from fastapi import FastAPI, UploadFile, File, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

import config
from employee_loader import load_employees, known_employees
from detector import PersonDetector
from tracker import PersonTracker
from face_recognition_module import FaceRecognizer
from reid import ReIDModule
from unknown_tracker import UnknownTracker
from websocket_manager import WebSocketManager
import image_analysis

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Employee Tracking Dashboard API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR   = Path("uploads");    UPLOAD_DIR.mkdir(exist_ok=True)
SNAPSHOT_DIR = Path("snapshots");  SNAPSHOT_DIR.mkdir(exist_ok=True)

app.mount("/snapshots", StaticFiles(directory="snapshots"), name="snapshots")

employees_store: dict = {}
unknown_store:   dict = {}
events_store:    List = []
event_counter = 0

# per-unknown-id, per-video snapshot url, e.g. {"UNK-1": {1: "http://.../a.jpg", 2: "http://.../b.jpg"}}
snapshots_by_video: dict = {}

ws_manager      = WebSocketManager()
detector        = PersonDetector()
face_recognizer = FaceRecognizer()
reid_module     = ReIDModule()

# Video pipeline's unknown-person gallery.
unknown_tracker = UnknownTracker(db_path=config.UNKNOWN_DB, id_prefix="UNK")

# Image analysis gets its OWN gallery/id-space (separate file, separate
# "IMG" prefix) so uploading images can never create, merge, or corrupt
# video identities and vice versa (Problem 3 in the brief). The detector /
# face_recognizer / reid_module *models* are safely shared (they're
# stateless feature extractors + the read-only enrolled-employee list) —
# it was only the mutable gallery/store state that needed isolating.
image_unknown_tracker = UnknownTracker(db_path=config.UNKNOWN_DB_IMAGES, id_prefix="IMG")

CAMERAS = [
    {
        "id": "cam01",
        "name": "Camera 01",
        "location": "Main Entrance",
        "status": "online",
        "fps": 25,
        "resolution": "1280x720",
    }
]


@app.on_event("startup")
async def startup_event():
    logger.info("Loading employee embeddings...")
    load_employees(face_recognizer, reid_module)
    logger.info(f"Loaded {len(known_employees)} employees.")


@app.get("/cameras")
def get_cameras():
    return CAMERAS

@app.get("/employees")
def get_employees():
    return list(employees_store.values())

@app.get("/unknowns")
def get_unknowns():
    return list(unknown_store.values())

@app.get("/events")
def get_events():
    return events_store[-200:]


@app.get("/settings")
def get_settings():
    return {
        "yolo_confidence":   config.YOLO_CONFIDENCE,
        "face_confidence":   config.FACE_CONFIDENCE,
        "reid_threshold":    config.REID_THRESHOLD,
        "unknown_threshold": config.REID_UNKNOWN_THRESH,
        "process_every_n":   config.PROCESS_EVERY_N,
        "bytetrack_buffer":  config.BYTETRACK_BUFFER,
        "yolo_model":        config.YOLO_MODEL,
        "reid_model":        config.REID_MODEL,
    }


@app.post("/settings")
async def save_settings(payload: dict):
    mapping = {
        "yolo_confidence":   "YOLO_CONFIDENCE",
        "face_confidence":   "FACE_CONFIDENCE",
        "reid_threshold":    "REID_THRESHOLD",
        "unknown_threshold": "REID_UNKNOWN_THRESH",
        "process_every_n":   "PROCESS_EVERY_N",
        "bytetrack_buffer":  "BYTETRACK_BUFFER",
    }
    for key, attr in mapping.items():
        if key in payload and payload[key] is not None:
            setattr(config, attr, payload[key])
    logger.info(f"Settings updated: {payload}")
    return get_settings()


@app.post("/reset")
async def reset_dashboard():
    global employees_store, unknown_store, events_store, event_counter, snapshots_by_video
    employees_store    = {}
    unknown_store       = {}
    events_store        = []
    event_counter       = 0
    snapshots_by_video  = {}
    # Only clear THIS session's UNK-1, UNK-2... display numbering. The
    # persistent gallery (embeddings + permanent internal ids) is left
    # intact, so a person seen before Reset is still correctly matched
    # (as a "reused" identity) if they reappear in a later video — they
    # just get a fresh sequential display number for the new session.
    unknown_tracker.reset_session()

    await ws_manager.broadcast({"type": "employee_update", "employees": []})
    await ws_manager.broadcast({"type": "unknown_update",  "unknowns":  []})
    await ws_manager.broadcast({"type": "event_update",    "events":    []})
    logger.info("Dashboard reset (session numbering cleared, gallery preserved).")
    return {"status": "reset"}


@app.post("/upload-video")
async def upload_video(file: UploadFile = File(...)):
    filename  = f"{uuid.uuid4()}_{file.filename}"
    save_path = UPLOAD_DIR / filename
    content   = await file.read()
    with open(save_path, "wb") as f:
        f.write(content)
    logger.info(f"Saved video: {save_path}")
    asyncio.create_task(process_video(str(save_path), video_id=1))
    return {"status": "uploaded", "filename": filename}


@app.post("/upload-dual-video")
async def upload_dual_video(video1: UploadFile = File(...), video2: UploadFile = File(...)):
    saved = []
    for f in (video1, video2):
        filename  = f"{uuid.uuid4()}_{f.filename}"
        save_path = UPLOAD_DIR / filename
        content   = await f.read()
        with open(save_path, "wb") as out:
            out.write(content)
        saved.append(str(save_path))
        logger.info(f"Saved video: {save_path}")

    # Run both videos concurrently, tagging events/unknowns with videoId 1 / 2
    # so the frontend can show cross-video re-identification.
    asyncio.create_task(process_video(saved[0], video_id=1))
    asyncio.create_task(process_video(saved[1], video_id=2))
    return {"status": "uploaded", "filenames": [Path(p).name for p in saved]}


@app.post("/analyze-image")
async def analyze_image_endpoint(file: UploadFile = File(...)):
    """
    Single-image analysis — detects every person, assigns identities
    (known employee or Unknown), draws bounding boxes.

    Fully independent of video processing state: uses its own
    `image_unknown_tracker` gallery (separate file + id-prefix), and never
    reads or writes employees_store / unknown_store / events_store, which
    belong to the live video dashboard.
    """
    try:
        image_bytes = await file.read()
        result = await image_analysis.analyze_image(
            image_bytes, detector, face_recognizer, reid_module, image_unknown_tracker,
            known_min_conf=50.0,
        )
        return result
    except Exception as e:
        # Any pipeline failure (bad crop, model not loaded, decode issue,
        # etc.) must come back as a normal {"error": ...} JSON body instead
        # of an unhandled 500 — the frontend only understands the former,
        # and would otherwise try to render a non-existent `summary` object
        # and crash instead of showing the user a clear message.
        logger.exception("Image analysis failed")
        return {"error": f"Image analysis failed: {e}"}


@app.post("/compare-images")
async def compare_images_endpoint(image1: UploadFile = File(...), image2: UploadFile = File(...)):
    """
    Two-image comparison — detects people in both images independently,
    then matches people across the two images by embedding similarity.
    Same person -> same identity in both images' results. Unmatched people
    are labelled Unknown. Does not persist into any long-term gallery (each
    comparison is self-contained), and never touches video state.
    """
    bytes1 = await image1.read()
    bytes2 = await image2.read()
    result = await image_analysis.compare_images(
        bytes1, bytes2, detector, face_recognizer, reid_module,
        known_min_conf=50.0,
    )
    return result


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        await websocket.send_json({"type": "employee_update", "employees": list(employees_store.values())})
        await websocket.send_json({"type": "event_update",   "events":    events_store[-50:]})
        await websocket.send_json({"type": "unknown_update", "unknowns":  list(unknown_store.values())})
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)


def save_snapshot(crop, name: str) -> str:
    fname = f"{name}_{uuid.uuid4().hex[:8]}.jpg"
    path  = SNAPSHOT_DIR / fname
    cv2.imwrite(str(path), crop)
    return f"http://localhost:8003/snapshots/{fname}"


async def process_video(video_path: str, video_id: int = 1):
    global event_counter
    logger.info(f"Processing video {video_id}: {video_path}")

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        logger.error(f"Cannot open video: {video_path}")
        await ws_manager.broadcast({
            "type": "processing_status", "videoId": video_id,
            "status": {"active": False, "progress": 0, "total_frames": 0, "processed": 0,
                       "fps": 0, "eta": "--", "video_name": Path(video_path).name},
        })
        return

    tracker       = PersonTracker()
    frame_idx     = 0
    last_event: dict = {}
    # How many processed frames each ByteTrack track_id has been seen for.
    # A track only gets identified once it's proven stable (config.MIN_TRACK_HITS)
    # — this is what stops a 1-2 frame ByteTrack fragment/flicker from ever
    # becoming its own "Unknown Person" card.
    track_hits: dict = {}
    # Once a track_id has been identified for the first time, its identity
    # is cached and reused for the rest of that track's life. Later frames
    # only *reinforce* the same identity (better snapshot, updated gallery)
    # instead of re-running the nearest-neighbour search — which is what
    # previously let per-frame embedding noise reassign the same physical
    # person to a brand-new UNK id mid-track.
    track_identity: dict = {}
    video_name    = Path(video_path).name
    total_frames  = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0
    start_time    = time.monotonic()

    async def broadcast_progress(active: bool):
        elapsed = max(time.monotonic() - start_time, 1e-6)
        fps     = round(frame_idx / elapsed, 1)
        progress = int(min(99 if active else 100, (frame_idx / total_frames) * 100)) if total_frames else (0 if active else 100)
        remaining_frames = max(total_frames - frame_idx, 0)
        eta_secs = int(remaining_frames / fps) if fps > 0 and total_frames else 0
        eta = f"{eta_secs}s" if active and total_frames else "--"
        await ws_manager.broadcast({
            "type": "processing_status", "videoId": video_id,
            "status": {
                "active": active, "progress": progress, "total_frames": total_frames,
                "processed": frame_idx, "fps": fps, "eta": eta, "video_name": video_name,
            },
        })

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            frame_idx += 1
            if frame_idx % max(1, config.PROCESS_EVERY_N) != 0:
                continue

            detections = detector.detect(frame)
            tracks     = tracker.update(detections, frame)

            for track in tracks:
                track_id        = track["track_id"]
                x1, y1, x2, y2 = track["bbox"]
                x1, y1 = max(0, x1), max(0, y1)
                x2, y2 = min(frame.shape[1], x2), min(frame.shape[0], y2)
                if x2 <= x1 or y2 <= y1:
                    continue

                crop = frame[y1:y2, x1:x2]
                if crop.size == 0:
                    continue

                # Track-stability gate: don't identify a track until it's
                # been seen for MIN_TRACK_HITS processed frames. Filters out
                # ByteTrack fragments/flicker so they never spawn an Unknown
                # Person card of their own.
                track_hits[track_id] = track_hits.get(track_id, 0) + 1
                if track_hits[track_id] < config.MIN_TRACK_HITS:
                    continue

                if last_event.get(track_id, -999) > frame_idx - 30:
                    continue
                last_event[track_id] = frame_idx

                cached_identity = track_identity.get(track_id)

                # Always attempt face recognition fresh — cheap, and lets an
                # Unknown track upgrade to a known employee once a clear
                # face appears. Body-ReID identity *search* only runs when
                # we don't already have a locked-in identity for this track;
                # once locked, later frames only reinforce that same id via
                # add_observation() below instead of risking a re-search
                # reassigning the same person to a different Unknown id.
                result = face_recognizer.recognize(crop)
                body_embedding = None
                if result is None or result["confidence"] < config.FACE_CONFIDENCE:
                    body_embedding = reid_module.embed(crop)
                    if cached_identity is None or not cached_identity.get("is_known"):
                        result = reid_module.identify_embedding(body_embedding)

                now_str    = datetime.now().strftime("%I:%M:%S %p")
                confidence = round((result["confidence"] if result else 0) * 100, 1)
                is_known   = bool(result and result["employee_id"] not in ("Unknown", None) and confidence >= 50)

                snapshot_url = save_snapshot(crop, f"{'known' if is_known else 'unknown'}_{track_id}")
                event_counter += 1

                if is_known:
                    emp_id   = result["employee_id"]
                    emp_name = result["employee_name"]
                    track_identity[track_id] = {"is_known": True, "id": emp_id}

                    if emp_id not in employees_store:
                        employees_store[emp_id] = {
                            "id":             str(uuid.uuid4()),
                            "employeeId":     emp_id,
                            "name":           emp_name,
                            "trackId":        f"#{track_id}",
                            "confidence":     confidence,
                            "detectionCount": 1,
                            "status":         "active",
                            "firstSeen":      now_str,
                            "lastSeen":       now_str,
                            "timeTracked":    "0m",
                            "snapshotUrl":    snapshot_url,
                            "videoId":        video_id,
                        }
                    else:
                        employees_store[emp_id].update({
                            "detectionCount": employees_store[emp_id]["detectionCount"] + 1,
                            "lastSeen":       now_str,
                            "confidence":     confidence,
                            "trackId":        f"#{track_id}",
                            "snapshotUrl":    snapshot_url,
                            "status":         "active",
                            "videoId":        video_id,
                        })

                    event = {
                        "id":           f"ev-{event_counter}",
                        "timestamp":    now_str,
                        "employeeId":   emp_id,
                        "employeeName": emp_name,
                        "cameraId":     "cam01",
                        "cameraName":   "Camera 01",
                        "confidence":   confidence,
                        "type":         "known",
                        "snapshotUrl":  snapshot_url,
                        "videoId":      video_id,
                    }

                else:
                    embedding = body_embedding if body_embedding is not None else reid_module.embed(crop)

                    if cached_identity is not None and not cached_identity["is_known"]:
                        # This track already has an assigned Unknown identity
                        # — reinforce it instead of running a fresh search
                        # that could, on a noisy frame, match/create a
                        # *different* Unknown id for the same person.
                        unk_id  = cached_identity["id"]
                        reused  = unknown_tracker.add_observation(
                            unk_id, embedding, now_str, snapshot_url, confidence / 100.0, video_id=video_id,
                        )
                    else:
                        unk_id, reused = unknown_tracker.identify_or_create(
                            embedding, now_str, snapshot_url, confidence / 100.0, video_id=video_id,
                        )
                        track_identity[track_id] = {"is_known": False, "id": unk_id}

                    snapshots_by_video.setdefault(unk_id, {})[video_id] = snapshot_url

                    # unk_id above is the PERMANENT internal id (used as the
                    # dict key here, and for gallery/ReID matching). What we
                    # actually show the frontend is the session-scoped
                    # sequential display id (UNK-1, UNK-2, ...) so the
                    # gallery doesn't jump straight to UNK-32 just because
                    # 31 unknowns already exist in the persisted gallery.
                    display_unk_id = unknown_tracker.display_id(unk_id)

                    unknown_store[unk_id] = {
                        "id":                 unknown_store.get(unk_id, {}).get("id", str(uuid.uuid4())),
                        "unknownId":          display_unk_id,
                        "trackId":            f"#{track_id}",
                        "firstSeen":          unknown_tracker.get_first_seen(unk_id) or now_str,
                        "lastSeen":           unknown_tracker.get_last_seen(unk_id) or now_str,
                        "detectionCount":     unknown_tracker.get_appearances(unk_id),
                        "appearances":        unknown_tracker.get_appearances(unk_id),
                        "confidence":         confidence,
                        "snapshotUrl":        snapshot_url,
                        "status":             "unknown",
                        "videoId":            video_id,
                        "videos":             unknown_tracker.get_videos(unk_id),
                        "reusedAcrossVideos": unknown_tracker.is_cross_video(unk_id),
                        "snapshotsByVideo":   dict(snapshots_by_video.get(unk_id, {})),
                    }

                    event = {
                        "id":                f"ev-{event_counter}",
                        "timestamp":         now_str,
                        "employeeId":        None,
                        "employeeName":      "Unknown",
                        "unknownId":         display_unk_id,
                        "cameraId":          "cam01",
                        "cameraName":        "Camera 01",
                        "confidence":        confidence,
                        "type":              "unknown",
                        "snapshotUrl":       snapshot_url,
                        "videoId":           video_id,
                        "reusedAcrossVideos": reused,
                    }

                events_store.append(event)
                if len(events_store) > 1000:
                    events_store.pop(0)

                await ws_manager.broadcast({"type": "employee_update", "employees": list(employees_store.values())})
                await ws_manager.broadcast({"type": "unknown_update",  "unknowns":  list(unknown_store.values())})
                await ws_manager.broadcast({"type": "event_update",    "events":    [event]})
                await ws_manager.broadcast({"type": "detection_alert", "event":     event})
                await broadcast_progress(active=True)
                await asyncio.sleep(0)

    finally:
        cap.release()
        await broadcast_progress(active=False)
        logger.info(f"Finished processing video {video_id}: {video_path}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=config.BACKEND_HOST, port=config.BACKEND_PORT)
