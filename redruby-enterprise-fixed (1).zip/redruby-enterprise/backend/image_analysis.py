"""
image_analysis.py — Image analysis, fully isolated from video processing.

Two entry points, both self-contained (no dependency on the video
pipeline's employees_store / unknown_store / events_store / gallery):

  - analyze_image(...)   -> single image: detect + identify every person.
  - compare_images(...)  -> two images: detect + identify in each, then
                             match people across the two images so the same
                             physical person gets the same label in both.

Both reuse the same YOLO / face-recognition / ReID *model* instances as
the video pipeline (those are stateless feature extractors plus the
read-only enrolled-employee list, so sharing them is fine and is in fact
what makes "ReID module functioning correctly" true for images too). What
they do NOT share is any mutable gallery or store — `analyze_image` is
given its own dedicated `UnknownTracker` instance (see app.py), and
`compare_images` doesn't touch a persistent gallery at all: it matches
purely within the two uploaded images.
"""
import time
import uuid
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional

import cv2
import numpy as np

from config import SNAPSHOT_DIR, BACKEND_URL, SNAPSHOT_QUALITY, YOLO_MODEL, FACE_MODEL, REID_MODEL

logger = logging.getLogger(__name__)

# Video_id tag used only for the image gallery's own bookkeeping (cross-video
# fields are irrelevant here since images never mix with video state, but the
# UnknownTracker API still expects one).
IMAGE_VIDEO_ID = 0


def _draw_annotations(frame: np.ndarray, people: List[Dict]) -> np.ndarray:
    """Draw color-coded bounding boxes + labels on a copy of the frame."""
    annotated = frame.copy()
    for p in people:
        x1, y1, x2, y2 = p["bbox"]
        is_known = p["type"] == "known"
        color = (80, 200, 120) if is_known else (0, 140, 245)  # BGR: green / orange
        label = f"{p['name']}" if is_known else f"{p['unknownId']}"
        sub = f"{p['confidence']}%"

        cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
        text = f"{label}  {sub}"
        (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 2)
        cv2.rectangle(annotated, (x1, max(0, y1 - th - 12)), (x1 + tw + 10, y1), color, -1)
        cv2.putText(annotated, text, (x1 + 5, y1 - 6),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (15, 15, 15), 2, cv2.LINE_AA)
    return annotated


def _save_image(img: np.ndarray, prefix: str) -> str:
    fname = f"{prefix}_{uuid.uuid4().hex[:8]}.jpg"
    path = SNAPSHOT_DIR / fname
    cv2.imwrite(str(path), img, [cv2.IMWRITE_JPEG_QUALITY, SNAPSHOT_QUALITY])
    return f"{BACKEND_URL}/snapshots/{fname}"


def _decode(image_bytes: bytes) -> Optional[np.ndarray]:
    arr = np.frombuffer(image_bytes, dtype=np.uint8)
    return cv2.imdecode(arr, cv2.IMREAD_COLOR)


def _detect_people(frame: np.ndarray, detector, face_recognizer, reid_module) -> List[Dict]:
    """
    Run detection + face/body embedding extraction on one frame. Returns a
    list of raw per-person dicts (bbox, crop, embeddings, face-match info)
    that both analyze_image and compare_images build on top of.
    """
    detections = detector.detect(frame)
    out = []
    for det in detections:
        x1, y1, x2, y2 = det["bbox"]
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(frame.shape[1], x2), min(frame.shape[0], y2)
        if x2 <= x1 or y2 <= y1:
            continue
        crop = frame[y1:y2, x1:x2]
        if crop.size == 0:
            continue

        body_emb = reid_module.embed(crop)
        face_r = face_recognizer.recognize(crop)
        reid_r = reid_module.identify_embedding(body_emb) if body_emb is not None else None

        if face_r is not None and face_r.get("employee_id") not in ("Unknown", None):
            result, source = face_r, "face"
        elif reid_r is not None and reid_r.get("employee_id") not in ("Unknown", None):
            result, source = reid_r, "reid"
        else:
            result = face_r if (face_r and face_r["confidence"] >= (reid_r["confidence"] if reid_r else 0)) else reid_r
            source = "none"

        face_crop = face_recognizer.get_face_crop(crop)
        out.append({
            "bbox": [x1, y1, x2, y2],
            "crop": crop,
            "face_crop": face_crop,
            "body_emb": body_emb,
            "result": result,
            "source": source,
            "detection_confidence": det["confidence"],
        })
    return out


def _build_summary(people: List[Dict], processing_ms: float) -> str:
    total = len(people)
    known = [p for p in people if p["type"] == "known"]
    unknown = [p for p in people if p["type"] == "unknown"]
    repeated = [p for p in unknown if p.get("previouslySeen")]
    new_unk = [p for p in unknown if not p.get("previouslySeen")]

    if total == 0:
        return "No persons were detected in this image."

    parts = [f"{total} person{'s' if total != 1 else ''} detected in {processing_ms:.0f}ms."]

    if known:
        names = ", ".join(f"{p['name']} ({p['employeeId']})" for p in known)
        parts.append(f"{len(known)} recognized employee{'s' if len(known) != 1 else ''}: {names}.")

    if unknown:
        parts.append(f"{len(unknown)} unrecognized person{'s' if len(unknown) != 1 else ''} detected.")
        if repeated:
            ids = ", ".join(p["unknownId"] for p in repeated)
            parts.append(f"{len(repeated)} of them {'is' if len(repeated) == 1 else 'are'} a previously "
                          f"seen unknown visitor ({ids}) — matched via body Re-ID against this image's gallery.")
        if new_unk:
            parts.append(f"{len(new_unk)} new unknown identit{'y' if len(new_unk) == 1 else 'ies'} assigned.")

    if not known and unknown:
        parts.append("No enrolled employees were identified — all detected persons are unrecognized.")

    return " ".join(parts)


async def analyze_image(
    image_bytes: bytes,
    detector, face_recognizer, reid_module, image_unknown_tracker,
    known_min_conf: float = 50.0,
) -> Dict[str, Any]:
    """
    Full single-image pipeline. Entirely self-contained: builds its own
    response, saves its own snapshots, and only reads/writes
    `image_unknown_tracker` — never the video dashboard's stores.
    """
    t0 = time.time()

    frame = _decode(image_bytes)
    if frame is None:
        return {"error": "Could not decode image. Please upload a valid JPG or PNG."}

    now_str = datetime.now().strftime("%I:%M:%S %p")
    raw_people = _detect_people(frame, detector, face_recognizer, reid_module)

    people: List[Dict] = []
    conf_face_scores, conf_reid_scores, conf_detect_scores = [], [], []

    for idx, p in enumerate(raw_people):
        x1, y1, x2, y2 = p["bbox"]
        result, source, crop, face_crop = p["result"], p["source"], p["crop"], p["face_crop"]
        conf_detect_scores.append(p["detection_confidence"])

        conf = round((result["confidence"] if result else 0.0) * 100, 1)
        is_known = (result is not None
                    and result.get("employee_id") not in ("Unknown", None)
                    and conf >= known_min_conf)
        if source == "face" and result:
            conf_face_scores.append(result["confidence"] * 100)
        elif source == "reid" and result:
            conf_reid_scores.append(result["confidence"] * 100)

        has_face = face_crop is not None
        snap_img = face_crop if has_face else crop

        previously_seen = False
        unk_id = None
        display_unk_id = None

        if is_known:
            identity_id = result["employee_id"]
        else:
            unk_id, _ = image_unknown_tracker.identify_or_create(
                p["body_emb"], now_str, "", conf / 100.0, video_id=IMAGE_VIDEO_ID,
            )
            identity_id = unk_id
            previously_seen = image_unknown_tracker.get_appearances(unk_id) > 1
            # Show the session-scoped sequential id (IMG-1, IMG-2, ...),
            # not the permanent internal id (IMG-32) used for gallery
            # matching — same reasoning as the video gallery's UNK-N ids.
            display_unk_id = image_unknown_tracker.display_id(unk_id)

        snap_url = _save_image(snap_img, f"{'known' if is_known else 'unk'}_img")
        full_crop_url = _save_image(crop, f"{'known' if is_known else 'unk'}_img_body")

        people.append({
            "bbox": [x1, y1, x2, y2],
            "type": "known" if is_known else "unknown",
            "name": result["employee_name"] if is_known and result else None,
            "employeeId": result["employee_id"] if is_known and result else None,
            "unknownId": display_unk_id,
            "confidence": conf,
            "detectionConfidence": round(p["detection_confidence"] * 100, 1),
            "matchSource": source,
            "hasFace": has_face,
            "snapshotUrl": snap_url,
            "fullCropUrl": full_crop_url,
            "previouslySeen": previously_seen,
            "crossVideoMatch": False,  # image analysis is isolated from video state
            "timestamp": now_str,
        })

    annotated = _draw_annotations(frame, people)
    annotated_url = _save_image(annotated, "analysis_full")
    processing_ms = (time.time() - t0) * 1000

    summary = {
        "totalPersons": len(people),
        "knownCount": len([p for p in people if p["type"] == "known"]),
        "unknownCount": len([p for p in people if p["type"] == "unknown"]),
        "avgDetectionConfidence": round(sum(conf_detect_scores) / len(conf_detect_scores) * 100, 1) if conf_detect_scores else 0.0,
        "avgFaceConfidence": round(sum(conf_face_scores) / len(conf_face_scores), 1) if conf_face_scores else 0.0,
        "avgReidConfidence": round(sum(conf_reid_scores) / len(conf_reid_scores), 1) if conf_reid_scores else 0.0,
        "processingTimeMs": round(processing_ms, 1),
        "models": {"detection": YOLO_MODEL, "faceRecognition": FACE_MODEL, "reid": REID_MODEL},
        "imageWidth": int(frame.shape[1]),
        "imageHeight": int(frame.shape[0]),
    }

    return {
        "summary": summary,
        "people": people,
        "annotatedImageUrl": annotated_url,
        "aiSummaryText": _build_summary(people, processing_ms),
        "timestamp": now_str,
    }


async def compare_images(
    image1_bytes: bytes,
    image2_bytes: bytes,
    detector, face_recognizer, reid_module,
    known_min_conf: float = 50.0,
) -> Dict[str, Any]:
    """
    Detect + identify people independently in each image, then match people
    across the two images purely by embedding similarity (no persistent
    gallery involved — this comparison is self-contained per request).

    Known employees are labelled by employee id/name in both images
    automatically (they're matched against the shared enrolled-employee
    list, so no extra cross-image matching needed). Unrecognized people are
    matched against each other: image2's people are compared to image1's
    people, and the best mutual match above config.REID_UNKNOWN_THRESH gets
    the same "Person-N" label in both images. Anyone left unmatched is
    labelled Unknown, per spec.
    """
    import config as cfg

    t0 = time.time()
    frame1, frame2 = _decode(image1_bytes), _decode(image2_bytes)
    if frame1 is None or frame2 is None:
        return {"error": "Could not decode one or both images. Please upload valid JPG or PNG files."}

    now_str = datetime.now().strftime("%I:%M:%S %p")
    raw1 = _detect_people(frame1, detector, face_recognizer, reid_module)
    raw2 = _detect_people(frame2, detector, face_recognizer, reid_module)

    def classify(p):
        result, conf = p["result"], round((p["result"]["confidence"] if p["result"] else 0.0) * 100, 1)
        is_known = (result is not None and result.get("employee_id") not in ("Unknown", None)
                    and conf >= known_min_conf)
        return is_known, conf

    # Greedy mutual-best-match pairing between image1's unknown people and
    # image2's unknown people, using body ReID embeddings.
    unk1_idx = [i for i, p in enumerate(raw1) if not classify(p)[0]]
    unk2_idx = [i for i, p in enumerate(raw2) if not classify(p)[0]]

    pair_scores = []
    for i in unk1_idx:
        e1 = raw1[i]["body_emb"]
        if e1 is None:
            continue
        for j in unk2_idx:
            e2 = raw2[j]["body_emb"]
            if e2 is None:
                continue
            score = float(np.dot(e1, e2) / (np.linalg.norm(e1) * np.linalg.norm(e2) + 1e-8))
            pair_scores.append((score, i, j))
    pair_scores.sort(key=lambda t: t[0], reverse=True)

    matched_1, matched_2 = {}, {}
    person_counter = 0
    for score, i, j in pair_scores:
        if i in matched_1 or j in matched_2:
            continue
        if score < cfg.REID_UNKNOWN_THRESH:
            continue
        person_counter += 1
        label = f"Person-{person_counter}"
        matched_1[i] = (label, score)
        matched_2[j] = (label, score)

    def build_people(raw_list, frame, matched, unmatched_prefix):
        people = []
        unmatched_counter = 0
        for idx, p in enumerate(raw_list):
            x1, y1, x2, y2 = p["bbox"]
            is_known, conf = classify(p)
            result, source = p["result"], p["source"]
            has_face = p["face_crop"] is not None
            snap_img = p["face_crop"] if has_face else p["crop"]
            snap_url = _save_image(snap_img, f"{'known' if is_known else 'cmp'}_img")
            full_crop_url = _save_image(p["crop"], f"{'known' if is_known else 'cmp'}_img_body")

            if is_known:
                identity_label = result["employee_name"]
                unknown_id = None
                matched_person = True
            elif idx in matched:
                identity_label, match_score = matched[idx]
                unknown_id = identity_label
                matched_person = True
            else:
                unmatched_counter += 1
                identity_label = "Unknown"
                unknown_id = None
                matched_person = False

            people.append({
                "bbox": [x1, y1, x2, y2],
                "type": "known" if is_known else "unknown",
                "name": result["employee_name"] if is_known and result else None,
                "employeeId": result["employee_id"] if is_known and result else None,
                "unknownId": unknown_id,
                "label": identity_label,
                "matchedAcrossImages": matched_person,
                "confidence": conf,
                "detectionConfidence": round(p["detection_confidence"] * 100, 1),
                "matchSource": source,
                "hasFace": has_face,
                "snapshotUrl": snap_url,
                "fullCropUrl": full_crop_url,
                "timestamp": now_str,
            })
        return people

    people1 = build_people(raw1, frame1, matched_1, "Unknown")
    people2 = build_people(raw2, frame2, matched_2, "Unknown")

    annotated1 = _draw_annotations_labelled(frame1, people1)
    annotated2 = _draw_annotations_labelled(frame2, people2)
    annotated1_url = _save_image(annotated1, "compare_img1")
    annotated2_url = _save_image(annotated2, "compare_img2")

    processing_ms = (time.time() - t0) * 1000
    shared_labels = sorted(set(matched_1[i][0] for i in matched_1))

    total1, total2 = len(people1), len(people2)
    summary_text = (
        f"{total1} person(s) detected in image 1, {total2} in image 2, "
        f"{len(shared_labels)} matched across both images in {processing_ms:.0f}ms."
    )

    return {
        "image1": {"people": people1, "annotatedImageUrl": annotated1_url,
                    "imageWidth": int(frame1.shape[1]), "imageHeight": int(frame1.shape[0])},
        "image2": {"people": people2, "annotatedImageUrl": annotated2_url,
                    "imageWidth": int(frame2.shape[1]), "imageHeight": int(frame2.shape[0])},
        "matchedLabels": shared_labels,
        "processingTimeMs": round(processing_ms, 1),
        "aiSummaryText": summary_text,
        "timestamp": now_str,
    }


def _draw_annotations_labelled(frame: np.ndarray, people: List[Dict]) -> np.ndarray:
    """Like _draw_annotations, but uses the cross-image `label` field
    (Person-N / employee name / Unknown) instead of a gallery unknownId."""
    annotated = frame.copy()
    for p in people:
        x1, y1, x2, y2 = p["bbox"]
        is_known = p["type"] == "known"
        color = (80, 200, 120) if is_known else ((0, 200, 220) if p["matchedAcrossImages"] else (0, 140, 245))
        text = f"{p['label']}  {p['confidence']}%"

        cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
        (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 2)
        cv2.rectangle(annotated, (x1, max(0, y1 - th - 12)), (x1 + tw + 10, y1), color, -1)
        cv2.putText(annotated, text, (x1 + 5, y1 - 6),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (15, 15, 15), 2, cv2.LINE_AA)
    return annotated
