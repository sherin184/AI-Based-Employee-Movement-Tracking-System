"""
reid.py — OSNet-x0.25 body Re-Identification
Supports employee enrolment + unknown person matching.
"""
import logging
from typing import Optional, Dict, List
import numpy as np
import config
from config import REID_MODEL, REID_MARGIN, REID_MIN_CROP_SIZE

logger = logging.getLogger(__name__)


class ReIDModule:
    def __init__(self):
        self.model      = None
        self.transform  = None
        self._torch     = None
        self._enrolled: Dict[str, Dict] = {}
        self._load()

    def _load(self):
        try:
            import torch
            import torchreid
            import torchvision.transforms as T

            self.model = torchreid.models.build_model(
                name=REID_MODEL, num_classes=1000, pretrained=True
            )
            self.model.eval()
            if torch.cuda.is_available():
                self.model = self.model.cuda()

            self.transform = T.Compose([
                T.ToPILImage(),
                T.Resize((256, 128)),
                T.ToTensor(),
                T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ])
            self._torch = torch
            logger.info(f"ReID ({REID_MODEL}) loaded.")
        except Exception as e:
            logger.error(f"ReID load failed: {e}")

    def enroll_employee(self, emp_id: str, name: str, images: List[np.ndarray]):
        if self.model is None:
            return
        embeddings = [e for e in (self.embed(img) for img in images) if e is not None]
        if embeddings:
            self._enrolled[emp_id] = {"name": name, "embeddings": embeddings}
            logger.info(f"ReID enrolled {emp_id} ({name}) — {len(embeddings)} sample(s)")

    def embed(self, img_bgr: np.ndarray) -> Optional[np.ndarray]:
        """Compute normalised body embedding for one BGR crop."""
        if self.model is None:
            if not getattr(self, "_warned_no_model", False):
                logger.warning("ReID model is not loaded — every unidentified person will get "
                              "a brand-new UNK-id instead of being re-matched (no cross-video "
                              "or occlusion recovery). Check the 'ReID load failed' line earlier "
                              "in the logs, usually a missing 'torchreid' install.")
                self._warned_no_model = True
            return None
        if img_bgr is None or img_bgr.size == 0:
            return None
        h, w = img_bgr.shape[:2]
        if h < REID_MIN_CROP_SIZE or w < REID_MIN_CROP_SIZE:
            return None
        try:
            rgb    = img_bgr[:, :, ::-1].copy()
            tensor = self.transform(rgb).unsqueeze(0)
            if self._torch.cuda.is_available():
                tensor = tensor.cuda()
            with self._torch.no_grad():
                feat = self.model(tensor)
            feat = feat.cpu().numpy().flatten()
            n    = np.linalg.norm(feat)
            return (feat / n).astype(np.float32) if n > 1e-6 else None
        except Exception as e:
            logger.debug(f"ReID embed error: {e}")
            return None

    def identify_embedding(self, embedding: np.ndarray) -> Optional[Dict]:
        """Match pre-computed embedding against enrolled employees."""
        if not self._enrolled or embedding is None:
            return None

        per_employee_best: Dict[str, float] = {}
        per_employee_name: Dict[str, str]   = {}
        for emp_id, data in self._enrolled.items():
            scores = [float(np.dot(embedding, ref)) for ref in data["embeddings"]]
            per_employee_best[emp_id] = max(scores) if scores else -1.0
            per_employee_name[emp_id] = data["name"]

        ranked = sorted(per_employee_best.items(), key=lambda kv: kv[1], reverse=True)
        best_id, best_score = ranked[0]
        runner_up_score = ranked[1][1] if len(ranked) > 1 else -1.0

        if best_score < config.REID_THRESHOLD:
            return {"employee_id": "Unknown", "employee_name": "Unknown", "confidence": best_score}

        if runner_up_score >= 0 and (best_score - runner_up_score) < REID_MARGIN:
            logger.info(f"ReID: ambiguous body match {best_id}={best_score:.3f} vs "
                       f"runner-up={runner_up_score:.3f} → Unknown")
            return {"employee_id": "Unknown", "employee_name": "Unknown", "confidence": best_score}

        return {"employee_id": best_id, "employee_name": per_employee_name[best_id], "confidence": best_score}
