"""
detector.py — YOLOv11/v8 person detector
"""
import logging
from typing import List, Dict
import numpy as np
import config
from config import YOLO_MODEL, YOLO_CLASSES, MIN_BOX_HEIGHT_RATIO, MAX_BOX_ASPECT_RATIO

logger = logging.getLogger(__name__)


class PersonDetector:
    def __init__(self):
        self.model = None
        self._load()

    def _load(self):
        try:
            from ultralytics import YOLO
            import torch
            self.model = YOLO(YOLO_MODEL)
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
            self.half   = self.device == "cuda"  # FP16 only makes sense on GPU
            if self.device == "cuda":
                self.model.to(self.device)
            logger.info(f"YOLO loaded: {YOLO_MODEL} on {self.device} (fp16={self.half})")
        except Exception as e:
            self.device, self.half = "cpu", False
            logger.error(f"YOLO load failed: {e}")

    def detect(self, frame: np.ndarray) -> List[Dict]:
        """Returns list of {bbox:[x1,y1,x2,y2], confidence:float}

        Applies a shape/size quality gate on top of YOLO's own confidence
        so that small, non-person-shaped boxes (a raised hand close to the
        camera, a reflection, motion blur) don't get treated as a person.
        A real head/shoulders or full-body crop is taller than it is wide
        and occupies a meaningful fraction of the frame; a hand tends to be
        squarish/wide and comparatively small.
        """
        if self.model is None:
            return []
        try:
            frame_h = frame.shape[0]
            results = self.model.predict(
                source=frame, conf=config.YOLO_CONFIDENCE,
                classes=YOLO_CLASSES, verbose=False,
                device=self.device, half=self.half,
            )
            out = []
            for r in results:
                if r.boxes is None:
                    continue
                for box in r.boxes:
                    x1, y1, x2, y2 = box.xyxy[0].tolist()
                    w, h = x2 - x1, y2 - y1
                    if h <= 0 or w <= 0:
                        continue
                    if h < MIN_BOX_HEIGHT_RATIO * frame_h:
                        continue  # too small vs. frame — likely a hand/object, not a person
                    if (w / h) > MAX_BOX_ASPECT_RATIO:
                        continue  # too wide/flat to be a head+shoulders or body crop
                    out.append({
                        "bbox":       [int(x1), int(y1), int(x2), int(y2)],
                        "confidence": float(box.conf[0]),
                    })
            return out
        except Exception as e:
            logger.error(f"Detection error: {e}")
            return []