"""
employee_loader.py — Scans employees/ folder and enrolls everyone on startup.
Folder naming: EMPXXX_Name  (e.g. EMP001_John)
"""
import re
import logging
from pathlib import Path
from typing import TYPE_CHECKING
import cv2
from config import EMPLOYEE_DIR

if TYPE_CHECKING:
    from face_recognition_module import FaceRecognizer
    from reid import ReIDModule

logger = logging.getLogger(__name__)
known_employees: dict = {}

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
PATTERN    = re.compile(r"^(EMP\d+)_(.+)$", re.IGNORECASE)


def load_employees(face_recognizer: "FaceRecognizer", reid_module: "ReIDModule"):
    global known_employees
    known_employees.clear()

    if not EMPLOYEE_DIR.exists():
        logger.warning(f"employees/ not found at {EMPLOYEE_DIR}")
        return

    for emp_dir in sorted(EMPLOYEE_DIR.iterdir()):
        if not emp_dir.is_dir():
            continue
        m = PATTERN.match(emp_dir.name)
        if not m:
            logger.warning(f"Skipping unexpected folder: {emp_dir.name}")
            continue

        emp_id   = m.group(1).upper()
        emp_name = m.group(2)
        images   = []

        for img_path in sorted(emp_dir.iterdir()):
            if img_path.suffix.lower() not in IMAGE_EXTS:
                continue
            img = cv2.imread(str(img_path))
            if img is not None:
                images.append(img)

        if not images:
            logger.warning(f"No images for {emp_id} ({emp_name})")
            continue

        logger.info(f"Enrolling {emp_id} ({emp_name}) — {len(images)} image(s)")
        face_recognizer.enroll_employee(emp_id, emp_name, images)
        reid_module.enroll_employee(emp_id, emp_name, images)

        known_employees[emp_id] = {"id": emp_id, "name": emp_name, "images": len(images)}

    logger.info(f"Loaded {len(known_employees)} employee(s).")
