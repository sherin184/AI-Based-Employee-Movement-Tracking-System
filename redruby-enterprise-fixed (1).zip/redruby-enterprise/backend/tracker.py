"""
tracker.py — ByteTrack multi-object tracker (via supervision)
Higher lost_track_buffer means persons survive longer occlusions.
"""
import logging
from typing import List, Dict
import numpy as np
import config
from config import BYTETRACK_ACTIVATION, BYTETRACK_MATCH_THRESH, BYTETRACK_FPS

logger = logging.getLogger(__name__)


class PersonTracker:
    def __init__(self):
        self.tracker = None
        self._sv     = None
        self._load()

    def _load(self):
        try:
            import supervision as sv
            self.tracker = sv.ByteTrack(
                track_activation_threshold=BYTETRACK_ACTIVATION,
                lost_track_buffer=config.BYTETRACK_BUFFER,
                minimum_matching_threshold=BYTETRACK_MATCH_THRESH,
                frame_rate=BYTETRACK_FPS,
            )
            self._sv = sv
            logger.info("ByteTrack ready.")
        except Exception as e:
            logger.error(f"ByteTrack load failed: {e}")

    def update(self, detections: List[Dict], frame: np.ndarray) -> List[Dict]:
        if self.tracker is None or not detections:
            return []
        sv = self._sv
        xyxy      = np.array([d["bbox"] for d in detections], dtype=np.float32)
        confs     = np.array([d["confidence"] for d in detections], dtype=np.float32)
        class_ids = np.zeros(len(detections), dtype=int)

        sv_dets = sv.Detections(xyxy=xyxy, confidence=confs, class_id=class_ids)
        tracked = self.tracker.update_with_detections(sv_dets)

        return [
            {"track_id": int(tracked.tracker_id[i]),
             "bbox":     tracked.xyxy[i].astype(int).tolist()}
            for i in range(len(tracked))
        ]
