"""
unknown_tracker.py — Persistent unknown person identity manager.

Key design:
  - Rolling gallery of up to MAX_GALLERY embeddings per person.
  - Cosine similarity against mean gallery embedding for fast matching.
  - Survives backend restarts (saved to a JSON file on disk).
  - Internal ids (e.g. "UNK-32") are PERMANENT and never renumbered — this
    is what lets a person be re-identified across videos/sessions/restarts.
  - A separate, in-memory-only "session display id" (UNK-1, UNK-2, ...) is
    handed out lazily via display_id() for whatever the frontend shows.
    The dashboard's "Reset" button calls reset_session(), which clears
    just that numbering — the persistent gallery is untouched, so
    cross-video/cross-session re-identification keeps working after a
    Reset. Use reset() only for a genuine hard wipe.
  - Each pipeline (video vs. image analysis) must use its own instance,
    constructed with its own db_path/id_prefix — see app.py — so their
    identity spaces never mix.
  - Quality filtering: reject tiny/blurry crops before storing.
"""
import json
import logging
from pathlib import Path
from typing import Optional, Dict, List, Tuple
import numpy as np
from config import UNKNOWN_DB, REID_UNKNOWN_THRESH, REID_MAX_GALLERY

logger = logging.getLogger(__name__)


class UnknownTracker:
    """
    Manages one persistent gallery of "unknown person" identities.

    IMPORTANT: each pipeline that needs its own isolated identity space
    (e.g. video vs. image analysis) must construct its OWN UnknownTracker
    instance with a distinct `db_path` (and, ideally, a distinct
    `id_prefix`). Sharing a single instance/db file across pipelines is
    what causes identities and embeddings to leak between them.
    """

    def __init__(self, db_path: Path = UNKNOWN_DB, id_prefix: str = "UNK"):
        self._db: Dict[str, Dict] = {}
        self._counter = 0
        self._db_path = db_path
        self._id_prefix = id_prefix
        self._load()

        # ── Session display numbering ───────────────────────────────
        # `_counter` above is the PERSISTENT id counter — it must keep
        # climbing forever (never resets) so every unknown person ever
        # seen has a stable, unique internal id (e.g. "UNK-32") for
        # gallery/ReID matching, including matching people across videos
        # from a previous server session.
        #
        # The frontend, though, only cares about "who have I seen THIS
        # session" — it wants UNK-1, UNK-2, UNK-3... Persistent ids are
        # mapped to small sequential *display* ids lazily, the first time
        # each internal id is displayed in the current session. This map
        # is purely in-memory and is exactly what reset_session() clears.
        self._session_map: Dict[str, int] = {}
        self._session_counter = 0

    # ── Persistence ────────────────────────────────────────────────────

    def _load(self):
        if not self._db_path.exists():
            return
        try:
            data = json.loads(self._db_path.read_text())
            for unk_id, rec in data.items():
                raw  = rec.get("embeddings", [])
                embs = [self._norm(np.array(e, dtype=np.float32)) for e in raw]
                embs = [e for e in embs if e is not None]
                self._db[unk_id] = {
                    "embeddings":    embs,
                    "mean_emb":      self._mean(embs),
                    "first_seen":    rec.get("first_seen", ""),
                    "last_seen":     rec.get("last_seen", ""),
                    "appearances":   rec.get("appearances", 0),
                    "snapshot_url":  rec.get("snapshot_url", ""),
                    "confidence":    rec.get("confidence", 0.0),
                    "videos":        rec.get("videos", [1]),
                    "first_video":   rec.get("first_video", 1),
                }
            prefix = f"{self._id_prefix}-"
            nums = [int(k.split("-")[1]) for k in self._db if k.startswith(prefix)]
            self._counter = max(nums) if nums else 0
            logger.info(f"UnknownTracker[{self._id_prefix}]: loaded {len(self._db)} persons from disk.")
        except Exception as e:
            logger.warning(f"UnknownTracker load error: {e}")

    def _save(self):
        try:
            out = {}
            for uid, rec in self._db.items():
                out[uid] = {
                    "embeddings":   [e.tolist() for e in rec["embeddings"]],
                    "first_seen":   rec["first_seen"],
                    "last_seen":    rec["last_seen"],
                    "appearances":  rec["appearances"],
                    "snapshot_url": rec["snapshot_url"],
                    "confidence":   rec["confidence"],
                    "videos":       rec.get("videos", [1]),
                    "first_video":  rec.get("first_video", 1),
                }
            self._db_path.write_text(json.dumps(out, indent=2))
        except Exception as e:
            logger.warning(f"UnknownTracker save error: {e}")

    # ── Public API ─────────────────────────────────────────────────────

    def reset(self):
        """Hard reset: wipes the ENTIRE persistent gallery (embeddings,
        internal ids, counter) and the on-disk file. This intentionally
        breaks cross-video/cross-session matching for anyone seen before
        the wipe — it is NOT what the dashboard's "Reset" button calls.
        Kept around for an explicit hard-reset admin action if ever needed."""
        self._db      = {}
        self._counter = 0
        if self._db_path.exists():
            self._db_path.unlink()
        self.reset_session()
        logger.info(f"UnknownTracker[{self._id_prefix}] hard reset (gallery wiped).")

    def reset_session(self):
        """Clear ONLY the session's display numbering. The persistent
        gallery (embeddings, internal ids, counter) is left untouched, so
        a person who reappears in a video processed after this call is
        still correctly re-identified — they'll just be assigned a fresh
        sequential display id (UNK-1, UNK-2, ...) for the new session
        instead of reusing their old display number.

        This is what the dashboard's "Reset" button calls.
        """
        self._session_map = {}
        self._session_counter = 0
        logger.info(f"UnknownTracker[{self._id_prefix}] session numbering reset "
                    f"(persistent gallery of {len(self._db)} unchanged).")

    def display_id(self, internal_id: str) -> str:
        """
        Map a persistent internal id (e.g. "UNK-32") to this session's
        small sequential display id (e.g. "UNK-1"). Assigned lazily, in
        order of first appearance THIS session — stable for the rest of
        the session, reset by reset_session().

        Use this ONLY for what gets shown/sent to the frontend. All
        internal bookkeeping (dict keys, gallery matching, cross-video
        checks) must keep using the real internal id.
        """
        if internal_id not in self._session_map:
            self._session_counter += 1
            self._session_map[internal_id] = self._session_counter
        return f"{self._id_prefix}-{self._session_map[internal_id]}"

    def identify_or_create(
        self,
        embedding: Optional[np.ndarray],
        now_str: str,
        snapshot_url: str,
        confidence: float = 0.0,
        video_id: int = 1,
    ) -> Tuple[str, bool]:
        """
        Returns (unk_id, reused_across_videos).
        reused_across_videos is True when this identity was already known
        from a *different* video before this call — i.e. the same person
        was re-identified across camera feeds / video files.
        """
        norm_emb = self._norm(embedding)

        if norm_emb is not None:
            best_id, best_score = self._best_match(norm_emb)
            if best_id and best_score >= REID_UNKNOWN_THRESH:
                reused = self._update_existing(best_id, norm_emb, now_str, snapshot_url,
                                               confidence, best_score, video_id)
                return best_id, reused

        # New unknown person
        self._counter += 1
        unk_id = f"{self._id_prefix}-{self._counter}"
        self._db[unk_id] = {
            "embeddings":   [norm_emb] if norm_emb is not None else [],
            "mean_emb":     norm_emb,
            "first_seen":   now_str,
            "last_seen":    now_str,
            "appearances":  1,
            "snapshot_url": snapshot_url,
            "confidence":   confidence,
            "videos":       [video_id],
            "first_video":  video_id,
        }
        self._save()
        logger.info(f"New unknown: {unk_id} (first seen on Video {video_id})")
        return unk_id, False

    def add_observation(
        self,
        unk_id: str,
        embedding: Optional[np.ndarray],
        now_str: str,
        snapshot_url: str,
        confidence: float = 0.0,
        video_id: int = 1,
    ) -> bool:
        """
        Reinforce an identity that a CALLER has already decided this
        detection belongs to (e.g. because it's the same ByteTrack track_id
        we already matched a few frames ago) — updates the gallery/stats
        WITHOUT doing a fresh nearest-neighbour search.

        This is what stops per-track re-checks from ever assigning a
        different unknown identity to the same physical person: identity
        *search* (identify_or_create) only ever runs once per track, the
        rest of that track's frames just reinforce the id it already got.
        Returns cross-video-reuse flag same as identify_or_create.
        """
        if unk_id not in self._db:
            # Defensive: identity vanished somehow — recreate minimal record
            # rather than silently dropping the observation.
            self._db[unk_id] = {
                "embeddings": [], "mean_emb": None, "first_seen": now_str,
                "last_seen": now_str, "appearances": 0, "snapshot_url": "",
                "confidence": 0.0, "videos": [video_id], "first_video": video_id,
            }
        norm_emb = self._norm(embedding)
        if norm_emb is not None:
            return self._update_existing(
                unk_id, norm_emb, now_str, snapshot_url, confidence,
                match_score=confidence, video_id=video_id,
            )
        return self._touch_only(unk_id, now_str, snapshot_url, video_id)

    def _touch_only(self, unk_id: str, now_str: str, snapshot_url: str, video_id: int) -> bool:
        """Update stats for a track observation whose crop yielded no usable
        embedding (too small/blurry), without touching the gallery."""
        rec = self._db[unk_id]
        videos = rec.setdefault("videos", [rec.get("first_video", video_id)])
        is_new_video = video_id not in videos
        if is_new_video:
            videos.append(video_id)
        rec["last_seen"]   = now_str
        rec["appearances"] = rec["appearances"] + 1
        if snapshot_url:
            rec["snapshot_url"] = snapshot_url
        self._save()
        return is_new_video

    def _update_existing(self, unk_id: str, emb: np.ndarray, now_str: str,
                         snapshot_url: str, confidence: float, match_score: float,
                         video_id: int = 1) -> bool:
        rec     = self._db[unk_id]
        gallery = rec["embeddings"]

        videos = rec.setdefault("videos", [rec.get("first_video", video_id)])
        is_new_video = video_id not in videos
        reused_across_videos = is_new_video
        if is_new_video:
            videos.append(video_id)
            logger.info(f"Cross-video match! {unk_id} reused on Video {video_id} "
                       f"(first seen Video {rec.get('first_video', videos[0])}, score={match_score:.3f})")

        # Add embedding to rolling gallery
        gallery.append(emb)
        if len(gallery) > REID_MAX_GALLERY:
            gallery.pop(0)
        rec["mean_emb"]    = self._mean(gallery)
        rec["last_seen"]   = now_str
        rec["appearances"] = rec["appearances"] + 1
        rec["snapshot_url"] = snapshot_url
        rec["confidence"]  = max(rec["confidence"], match_score)
        self._save()
        logger.debug(f"Re-matched {unk_id} (score={match_score:.3f})")
        return reused_across_videos

    def get_first_seen(self, unk_id: str) -> str:
        return self._db.get(unk_id, {}).get("first_seen", "")

    def get_last_seen(self, unk_id: str) -> str:
        return self._db.get(unk_id, {}).get("last_seen", "")

    def get_appearances(self, unk_id: str) -> int:
        return self._db.get(unk_id, {}).get("appearances", 0)

    def get_videos(self, unk_id: str) -> List[int]:
        return self._db.get(unk_id, {}).get("videos", [])

    def is_cross_video(self, unk_id: str) -> bool:
        return len(self._db.get(unk_id, {}).get("videos", [])) > 1

    # ── Internals ──────────────────────────────────────────────────────

    def _best_match(self, query: np.ndarray) -> Tuple[Optional[str], float]:
        best_id, best_score = None, -1.0
        for uid, rec in self._db.items():
            # Compare against mean embedding first (fast)
            mean = rec.get("mean_emb")
            if mean is not None and mean.shape == query.shape:
                s = float(np.dot(query, mean))
                if s > best_score:
                    best_score = s
                    best_id    = uid
            # Also check individual embeddings for robustness
            for ref in rec["embeddings"]:
                if ref.shape != query.shape:
                    continue
                s = float(np.dot(query, ref))
                if s > best_score:
                    best_score = s
                    best_id    = uid
        return best_id, best_score

    @staticmethod
    def _norm(emb: Optional[np.ndarray]) -> Optional[np.ndarray]:
        if emb is None:
            return None
        n = np.linalg.norm(emb)
        return (emb / n).astype(np.float32) if n > 1e-6 else None

    @staticmethod
    def _mean(embeddings: List[np.ndarray]) -> Optional[np.ndarray]:
        if not embeddings:
            return None
        m = np.mean(np.stack(embeddings), axis=0)
        n = np.linalg.norm(m)
        return (m / n).astype(np.float32) if n > 1e-6 else None
