"""
snapshot_quality.py — Scores a person crop so the gallery always shows the
best available shot of someone, never a blank/blurry/tiny/off-center one.

Score (0-100) combines:
  • Sharpness   — Laplacian variance (blur detector)
  • Brightness  — penalise too-dark or blown-out crops
  • Size        — bigger, closer crops score higher (more detail)
  • Confidence  — the detector/recognizer's own confidence for this frame

A snapshot already stored for a person is only ever REPLACED if the new
one scores strictly higher — so quality only improves over time, it never
regresses to a worse frame.
"""
import numpy as np
import cv2

# Reject a crop outright (never use it as anyone's identification/snapshot
# source) if it fails these floors — a value below any of these means the
# frame is almost certainly noise (motion blur, near-black, a sliver of a
# person clipped at the frame edge) rather than a usable photo of them.
MIN_SHARPNESS   = 25.0     # Laplacian variance; below this = visibly blurred
MIN_BRIGHTNESS  = 25.0     # 0-255 mean; below this = essentially black
MAX_BRIGHTNESS  = 235.0    # 0-255 mean; above this = blown-out/washed-out
MIN_CROP_PIXELS = 900      # 30x30 or smaller = too small to be useful


def _sharpness(gray: np.ndarray) -> float:
    return float(cv2.Laplacian(gray, cv2.CV_64F).var())


def is_acceptable(crop: np.ndarray) -> bool:
    """Hard gate — reject unusable crops before they're ever saved or scored."""
    if crop is None or crop.size == 0:
        return False
    h, w = crop.shape[:2]
    if h * w < MIN_CROP_PIXELS:
        return False
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    brightness = float(gray.mean())
    if brightness < MIN_BRIGHTNESS or brightness > MAX_BRIGHTNESS:
        return False
    if _sharpness(gray) < MIN_SHARPNESS:
        return False
    return True


def compute_quality(crop: np.ndarray, detection_confidence: float = 0.0) -> float:
    """
    Returns a 0-100 quality score for this crop. Caller compares against a
    person's previously-stored score and only replaces the snapshot if this
    one is higher.
    """
    if crop is None or crop.size == 0:
        return 0.0

    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    h, w = crop.shape[:2]

    # Sharpness: normalise so ~300 Laplacian variance (a clearly in-focus
    # crop) maps to a full sharpness score; caps at 100.
    sharpness_score = min(100.0, (_sharpness(gray) / 300.0) * 100.0)

    # Brightness: 100 at ideal mid-tone (~130/255), falling off toward the
    # dark/bright rejection floors.
    brightness = float(gray.mean())
    ideal = 130.0
    brightness_score = max(0.0, 100.0 - abs(brightness - ideal) / ideal * 100.0)

    # Size: bigger crops (closer/clearer person) score higher, saturating
    # at a generous 200x200 crop so distant-but-in-frame people aren't
    # unfairly zeroed out.
    size_score = min(100.0, (min(h, w) / 200.0) * 100.0)

    # Confidence: the detector/recognizer's own confidence (0-1) for this
    # particular frame, folded in directly as a 0-100 contribution.
    conf_score = max(0.0, min(100.0, detection_confidence * 100.0))

    # Weighted blend — sharpness and confidence matter most for "is this a
    # usable, correctly-identified photo of the person".
    score = (
        sharpness_score  * 0.35 +
        brightness_score * 0.15 +
        size_score        * 0.20 +
        conf_score         * 0.30
    )
    return round(score, 1)