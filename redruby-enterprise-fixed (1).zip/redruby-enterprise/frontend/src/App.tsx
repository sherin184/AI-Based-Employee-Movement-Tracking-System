import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { TrackingSystemProvider } from './data/index';
import DashboardPage  from './pages/DashboardPage';
import EmployeesPage  from './pages/EmployeesPage';
import SettingsPage   from './pages/SettingsPage';
import DualVideoPage  from './pages/DualVideoPage';
import ImageAnalysisPage from './pages/ImageAnalysisPage';

export default function App() {
  return (
    <TrackingSystemProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/"          element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/dual-video" element={<DualVideoPage />} />
          <Route path="/image-analysis" element={<ImageAnalysisPage />} />
          <Route path="/employees" element={<EmployeesPage />} />
          <Route path="/settings"  element={<SettingsPage />} />
          <Route path="*"          element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </BrowserRouter>
    </TrackingSystemProvider>
  );
}
