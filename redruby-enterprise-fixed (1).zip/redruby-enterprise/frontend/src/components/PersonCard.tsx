
import { UserX, UserCheck, Clock } from 'lucide-react';
interface KnownProps { type:'known'; name:string; empId:string; confidence:number; firstSeen:string; lastSeen:string; snapshotUrl?:string; trackId:string; detectionCount:number; }
interface UnknownProps { type:'unknown'; unknownId:string; confidence:number; firstSeen:string; lastSeen:string; snapshotUrl?:string; trackId:string; detectionCount:number; appearances:number; }
type Props = KnownProps | UnknownProps;

export default function PersonCard(p:Props) {
  const isKnown = p.type === 'known';
  const snap = p.snapshotUrl;
  const initials = isKnown ? (p as KnownProps).name.slice(0,2).toUpperCase() : '?';
  return (
    <div className={`glass-card rounded-2xl p-4 border transition-all hover:border-border-bright animate-slide-up ${isKnown?'border-green/10':'border-orange/10'}`}>
      <div className="flex items-center gap-3 mb-3">
        <div className="relative flex-shrink-0">
          {snap ? <img src={snap} alt="" className="w-12 h-12 rounded-xl object-cover border border-border" onError={e=>(e.currentTarget.style.display='none')} />
            : <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-sm font-bold ${isKnown?'bg-green/10 text-green':'bg-orange/10 text-orange'}`}>{initials}</div>}
          <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center ${isKnown?'bg-green':'bg-orange'}`}>
            {isKnown ? <UserCheck className="w-2.5 h-2.5 text-white" /> : <UserX className="w-2.5 h-2.5 text-white" />}
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold text-text-primary truncate">
            {isKnown ? (p as KnownProps).name : (p as UnknownProps).unknownId}
          </p>
          <p className="text-[10px] text-text-muted">
            {isKnown ? (p as KnownProps).empId : `Track ${p.trackId}`}
          </p>
        </div>
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${isKnown?'bg-green/10 text-green':'bg-orange/10 text-orange'}`}>
          {p.confidence}%
        </span>
      </div>
      <div className="flex items-center gap-1 text-[9px] text-text-muted">
        <Clock className="w-2.5 h-2.5" />
        <span>{p.firstSeen} → {p.lastSeen}</span>
      </div>
    </div>
  );
}
