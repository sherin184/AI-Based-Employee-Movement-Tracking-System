import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Users, Settings, Shield, Layers, ImagePlus } from 'lucide-react';
import { useTracking } from '../data/index';

const NAV = [
  { path:'/dashboard',  label:'Dashboard',   icon:LayoutDashboard },
  { path:'/dual-video',  label:'Dual Video',  icon:Layers },
  { path:'/image-analysis', label:'Image Analysis', icon:ImagePlus },
  { path:'/employees',  label:'Analytics',   icon:Users },
  { path:'/settings',   label:'Settings',    icon:Settings },
];

export default function Sidebar() {
  const { pathname } = useLocation();
  const { isConnected, employees, unknowns, processing } = useTracking();
  const [time, setTime] = React.useState(new Date().toLocaleTimeString());
  React.useEffect(()=>{ const t=setInterval(()=>setTime(new Date().toLocaleTimeString()),1000); return ()=>clearInterval(t); },[]);

  return (
    <aside className="w-16 lg:w-56 h-screen fixed left-0 top-0 flex flex-col bg-dark-800 border-r border-border z-50">
      {/* Logo */}
      <div className="flex items-center gap-3 px-3 lg:px-4 py-5 border-b border-border">
        <div className="w-8 h-8 rounded-xl bg-accent flex items-center justify-center flex-shrink-0 glow-blue">
          <Shield className="w-4 h-4 text-white" />
        </div>
        <div className="hidden lg:block">
          <p className="text-sm font-bold text-text-primary leading-none">RedRuby</p>
          <p className="text-[10px] text-text-muted mt-0.5">Enterprise AI</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-2 space-y-1">
        {NAV.map(item => {
          const Icon = item.icon;
          const active = pathname === item.path;
          return (
            <Link key={item.path} to={item.path}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all group ${
                active ? 'bg-accent/20 text-accent' : 'text-text-secondary hover:bg-dark-600 hover:text-text-primary'
              }`}>
              <Icon className={`w-4 h-4 flex-shrink-0 ${active?'text-accent':''}`} />
              <span className="hidden lg:block text-xs font-semibold">{item.label}</span>
              {active && <div className="hidden lg:block ml-auto w-1.5 h-1.5 rounded-full bg-accent" />}
            </Link>
          );
        })}
      </nav>

      {/* Stats */}
      <div className="hidden lg:block p-3 border-t border-border space-y-2">
        <div className="flex justify-between text-[10px]">
          <span className="text-text-muted">Known</span>
          <span className="text-green font-bold">{employees.length}</span>
        </div>
        <div className="flex justify-between text-[10px]">
          <span className="text-text-muted">Unknown</span>
          <span className="text-orange font-bold">{unknowns.length}</span>
        </div>
        {processing.active && (
          <div className="flex justify-between text-[10px]">
            <span className="text-text-muted">Processing</span>
            <span className="text-accent font-bold">{processing.progress}%</span>
          </div>
        )}
      </div>

      {/* Status + time */}
      <div className="p-3 border-t border-border">
        <div className="hidden lg:flex items-center gap-2 mb-2">
          <div className={`w-1.5 h-1.5 rounded-full ${isConnected?'bg-green animate-pulse':'bg-red'}`} />
          <span className="text-[10px] text-text-muted">{isConnected?'Connected':'Offline'}</span>
        </div>
        <p className="hidden lg:block text-[10px] font-mono text-text-muted text-center">{time}</p>
        <div className={`lg:hidden w-2 h-2 rounded-full mx-auto ${isConnected?'bg-green animate-pulse':'bg-red'}`} />
      </div>
    </aside>
  );
}
