import React from 'react';
interface Props { label:string; value:string|number; sub?:string; icon:React.ReactNode; color:'blue'|'green'|'orange'|'purple'|'red'; trend?:number; }
export default function StatCard({label,value,sub,icon,color,trend}:Props) {
  const colors = { blue:'text-accent border-accent/20 bg-accent/10', green:'text-green border-green/20 bg-green/10', orange:'text-orange border-orange/20 bg-orange/10', purple:'text-purple border-purple/20 bg-purple/10', red:'text-red border-red/20 bg-red/10' };
  return (
    <div className="glass-card rounded-2xl p-5 animate-slide-up">
      <div className="flex items-start justify-between mb-4">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${colors[color]}`}>{icon}</div>
        {trend !== undefined && (
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${trend>=0?'bg-green/10 text-green':'bg-red/10 text-red'}`}>
            {trend>=0?'+':''}{trend}%
          </span>
        )}
      </div>
      <p className="text-2xl font-black text-text-primary">{value}</p>
      <p className="text-xs font-semibold text-text-secondary mt-1">{label}</p>
      {sub && <p className="text-[10px] text-text-muted mt-0.5">{sub}</p>}
    </div>
  );
}
