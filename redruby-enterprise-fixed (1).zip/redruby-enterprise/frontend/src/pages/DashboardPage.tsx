import { useRef, useState } from 'react';
import Sidebar from '../components/Sidebar';
import StatCard from '../components/StatCard';
import { useTracking } from '../data/index';
import { Upload, VideoOff, UserX, UserCheck, Radio, Activity, Maximize2, Minimize2, Wifi, WifiOff, Loader } from 'lucide-react';

export default function DashboardPage() {
  const { employees, unknowns, events, videoUrl, uploadVideo, isConnected, latestAlert, processing } = useTracking();
  const fileRef  = useRef<HTMLInputElement>(null);
  const [full,   setFull] = useState(false);
  const activeCount = employees.filter(e=>e.status==='active').length;

  return (
    <div className="flex h-screen overflow-hidden bg-dark-900">
      <Sidebar />

      {/* Alert popup */}
      {latestAlert && (
        <div className={`fixed top-4 right-4 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl shadow-glass border animate-slide-up pointer-events-none max-w-xs
          ${latestAlert.type==='known' ? 'bg-green/10 border-green/30' : 'bg-orange/10 border-orange/30'}`}>
          {latestAlert.snapshotUrl && <img src={latestAlert.snapshotUrl} alt="" className="w-10 h-10 rounded-lg object-cover border border-border flex-shrink-0" />}
          <div>
            <div className="flex items-center gap-1.5">
              {latestAlert.type==='known' ? <UserCheck className="w-3 h-3 text-green" /> : <UserX className="w-3 h-3 text-orange" />}
              <span className={`text-[10px] font-bold ${latestAlert.type==='known'?'text-green':'text-orange'}`}>
                {latestAlert.type==='known' ? 'Employee Identified' : 'Unknown Person'}
              </span>
            </div>
            <p className="text-sm font-black text-text-primary">{latestAlert.type==='known'?latestAlert.employeeName:(latestAlert.unknownId??'Unknown')}</p>
            <p className="text-[10px] text-text-muted">{latestAlert.confidence}% confidence</p>
          </div>
        </div>
      )}

      <main className="flex-1 ml-16 lg:ml-56 overflow-y-auto">
        {/* Top bar */}
        <header className="sticky top-0 z-40 bg-dark-800/80 backdrop-blur border-b border-border px-6 py-3 flex items-center justify-between">
          <div>
            <h1 className="text-sm font-bold text-text-primary">Surveillance Dashboard</h1>
            <p className="text-[10px] text-text-muted">Real-time AI person tracking</p>
          </div>
          <div className="flex items-center gap-3">
            {processing.active && (
              <div className="flex items-center gap-2 bg-accent/10 border border-accent/30 px-3 py-1.5 rounded-xl">
                <Loader className="w-3 h-3 text-accent animate-spin" />
                <span className="text-[10px] font-bold text-accent">{processing.progress}% • {processing.fps}fps • ETA {processing.eta}</span>
              </div>
            )}
            <div className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-[10px] font-bold ${isConnected?'bg-green/10 border-green/30 text-green':'bg-red/10 border-red/30 text-red'}`}>
              {isConnected?<Wifi className="w-3 h-3"/>:<WifiOff className="w-3 h-3"/>}
              {isConnected?'Connected':'Offline'}
            </div>
            <button onClick={()=>fileRef.current?.click()} className="flex items-center gap-2 px-4 py-1.5 bg-accent hover:bg-accent-hover text-white rounded-xl text-xs font-bold transition-all">
              <Upload className="w-3.5 h-3.5" />Upload Video
            </button>
            <input ref={fileRef} type="file" accept="video/*" className="hidden" onChange={e=>{const f=e.target.files?.[0];if(f)uploadVideo(f);}} />
          </div>
        </header>

        <div className="p-6 space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
            <StatCard label="Known Employees" value={employees.length} sub={`${activeCount} active`} icon={<UserCheck className="w-5 h-5"/>} color="green" />
            <StatCard label="Unknown Persons" value={unknowns.length} sub="Flagged for review" icon={<UserX className="w-5 h-5"/>} color="orange" />
            <StatCard label="Total Detections" value={events.length} sub="This session" icon={<Activity className="w-5 h-5"/>} color="blue" />
            <StatCard label="Processing" value={processing.active?`${processing.progress}%`:'Idle'} sub={processing.active?`${processing.fps} FPS`:'Upload a video'} icon={<Radio className="w-5 h-5"/>} color="purple" />
          </div>

          {/* Main layout: video + sidebar */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Video */}
            <div className={`xl:col-span-2 glass-card rounded-2xl overflow-hidden flex flex-col ${full?'fixed inset-4 z-50':''}`}>
              <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green animate-pulse" />
                  <span className="text-xs font-bold text-text-primary">LIVE FEED — Main Entrance</span>
                </div>
                <button onClick={()=>setFull(f=>!f)} className="text-text-muted hover:text-text-primary transition-colors">
                  {full?<Minimize2 className="w-4 h-4"/>:<Maximize2 className="w-4 h-4"/>}
                </button>
              </div>
              <div className="relative bg-dark-900 aspect-video flex items-center justify-center overflow-hidden flex-1">
                {videoUrl ? <video src={videoUrl} controls autoPlay loop muted className="w-full h-full object-cover" />
                  : <div className="flex flex-col items-center gap-3 text-center p-6">
                      <VideoOff className="w-12 h-12 text-text-muted/30" />
                      <p className="text-sm font-bold text-text-muted">No video loaded</p>
                      <p className="text-xs text-text-muted/60">Upload a CCTV video to begin detection</p>
                      <button onClick={()=>fileRef.current?.click()} className="mt-2 flex items-center gap-2 px-4 py-2 bg-accent/20 hover:bg-accent/30 border border-accent/30 text-accent rounded-xl text-xs font-bold transition-all">
                        <Upload className="w-3.5 h-3.5"/>Upload Video
                      </button>
                    </div>}
                {processing.active && (
                  <div className="absolute bottom-0 left-0 right-0 bg-dark-900/80 px-4 py-2">
                    <div className="flex justify-between text-[10px] text-text-muted mb-1">
                      <span>Processing: {processing.video_name}</span>
                      <span>{processing.progress}% • {processing.processed}/{processing.total_frames} frames • ETA {processing.eta}</span>
                    </div>
                    <div className="h-1 bg-dark-600 rounded-full overflow-hidden">
                      <div className="h-full bg-accent transition-all rounded-full" style={{width:`${processing.progress}%`}} />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right panel */}
            <div className="flex flex-col gap-4 overflow-y-auto max-h-[700px]">
              {/* Known */}
              <div className="glass-card rounded-2xl p-4">
                <div className="flex items-center gap-2 mb-3">
                  <UserCheck className="w-4 h-4 text-green" />
                  <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider">Known Persons</h3>
                  <span className="ml-auto text-[10px] font-bold bg-green/10 text-green px-2 py-0.5 rounded-full">{employees.length}</span>
                </div>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {employees.length===0 ? <p className="text-xs text-text-muted text-center py-4">No employees detected yet</p>
                    : employees.map(emp=>(
                    <div key={emp.id} className="flex items-center gap-3 bg-dark-700 rounded-xl p-2.5">
                      {emp.snapshotUrl ? <img src={emp.snapshotUrl} alt="" className="w-9 h-9 rounded-lg object-cover border border-border flex-shrink-0" />
                        : <div className="w-9 h-9 rounded-lg bg-green/10 flex items-center justify-center text-[10px] font-bold text-green flex-shrink-0">{emp.name.slice(0,2).toUpperCase()}</div>}
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-text-primary truncate">{emp.name}</p>
                        <p className="text-[10px] text-text-muted">{emp.employeeId} • {emp.confidence}%</p>
                        <p className="text-[9px] text-text-muted/70">{emp.firstSeen} → {emp.lastSeen}</p>
                      </div>
                      <span className="text-[9px] font-bold bg-green/10 text-green px-1.5 py-0.5 rounded-full flex-shrink-0">Verified</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Unknown */}
              <div className="glass-card rounded-2xl p-4">
                <div className="flex items-center gap-2 mb-3">
                  <UserX className="w-4 h-4 text-orange" />
                  <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider">Unknown Persons</h3>
                  <span className="ml-auto text-[10px] font-bold bg-orange/10 text-orange px-2 py-0.5 rounded-full">{unknowns.length}</span>
                </div>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {unknowns.length===0 ? <p className="text-xs text-text-muted text-center py-4">No unknowns detected</p>
                    : unknowns.map(unk=>(
                    <div key={unk.id} className="flex items-center gap-3 bg-dark-700 rounded-xl p-2.5 border border-orange/10">
                      {unk.snapshotUrl ? <img src={unk.snapshotUrl} alt="" className="w-9 h-9 rounded-lg object-cover border border-orange/20 flex-shrink-0" />
                        : <div className="w-9 h-9 rounded-lg bg-orange/10 flex items-center justify-center flex-shrink-0"><UserX className="w-4 h-4 text-orange"/></div>}
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-orange truncate">{unk.unknownId}</p>
                        <p className="text-[10px] text-text-muted">Track {unk.trackId}</p>
                        <p className="text-[9px] text-text-muted/70">{unk.firstSeen} → {unk.lastSeen}</p>
                      </div>
                      <span className="text-[9px] font-bold bg-orange/10 text-orange px-1.5 py-0.5 rounded-full flex-shrink-0">Unknown</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent detections */}
              <div className="glass-card rounded-2xl p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Radio className="w-4 h-4 text-accent animate-pulse" />
                  <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider">Recent Detections</h3>
                </div>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {events.length===0 ? <p className="text-xs text-text-muted text-center py-4">No detections yet</p>
                    : events.map(ev=>(
                    <div key={ev.id} className={`flex items-center gap-3 border-l-2 pl-3 py-1 ${ev.type==='known'?'border-green':'border-orange'}`}>
                      {ev.snapshotUrl && <img src={ev.snapshotUrl} alt="" className="w-8 h-8 rounded-lg object-cover border border-border flex-shrink-0" />}
                      <div>
                        <p className="text-xs font-bold text-text-primary">
                          {ev.type==='known'?ev.employeeName:(ev.unknownId??'Unknown')}
                          <span className={`ml-2 text-[9px] px-1.5 py-0.5 rounded-full font-bold ${ev.type==='known'?'bg-green/10 text-green':'bg-orange/10 text-orange'}`}>
                            {ev.type==='known'?'Known':'Unknown'}
                          </span>
                        </p>
                        <p className="text-[9px] text-text-muted">{ev.cameraName} • {ev.timestamp} • {ev.confidence}%</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
