import React, { useState, useRef, useCallback } from 'react';
import Sidebar from '../components/Sidebar';
import { API } from '../data/index';
import {
  ImagePlus, Upload, X, Loader, UserCheck, UserX, Eye, EyeOff,
  ZoomIn, ZoomOut, Maximize2, Minimize2, Download, FileText,
  Sparkles, GitCompare, Clock, Gauge, Tag, ChevronDown, ChevronRight,
  AlertTriangle, ImageOff,
} from 'lucide-react';

// ── Types matching the backend /analyze-image response ─────────────────
interface Person {
  bbox: [number, number, number, number];
  type: 'known' | 'unknown';
  name: string | null;
  employeeId: string | null;
  unknownId: string | null;
  confidence: number;
  detectionConfidence: number;
  matchSource: string;
  hasFace: boolean;
  snapshotUrl: string;
  fullCropUrl: string;
  previouslySeen: boolean;
  crossVideoMatch: boolean;
  timestamp: string;
}
interface AnalysisResult {
  summary: {
    totalPersons: number; knownCount: number; unknownCount: number;
    avgDetectionConfidence: number; avgFaceConfidence: number; avgReidConfidence: number;
    processingTimeMs: number;
    models: { detection: string; faceRecognition: string; reid: string };
    imageWidth: number; imageHeight: number;
  };
  people: Person[];
  annotatedImageUrl: string;
  aiSummaryText: string;
  timestamp: string;
}

export default function ImageAnalysisPage() {
  const [file, setFile]           = useState<File | null>(null);
  const [previewUrl, setPreview]  = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult]       = useState<AnalysisResult | null>(null);
  const [error, setError]         = useState<string | null>(null);
  const [dragOver, setDragOver]   = useState(false);

  const [showBoxes, setShowBoxes]   = useState(true);
  const [zoom, setZoom]             = useState(1);
  const [fullscreen, setFullscreen] = useState(false);
  const [confFilter, setConfFilter] = useState(0);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const fileRef = useRef<HTMLInputElement>(null);

  const reset = () => {
    setFile(null); setPreview(null); setResult(null); setError(null);
    setZoom(1); setShowBoxes(true); setConfFilter(0);
  };

  const handleFile = useCallback((f: File) => {
    if (!f.type.match(/image\/(jpeg|jpg|png)/)) {
      setError('Only JPG, JPEG, or PNG images are supported.');
      return;
    }
    setError(null);
    setFile(f);
    setPreview(URL.createObjectURL(f));
    setResult(null);
  }, []);

  const analyze = async () => {
    if (!file) return;
    setAnalyzing(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const res = await fetch(`${API}/analyze-image`, { method: 'POST', body: fd });
      let data: any = null;
      try { data = await res.json(); } catch { /* non-JSON response, handled below */ }

      if (!res.ok) {
        setError((data && (data.error || data.detail)) || `Analysis failed (HTTP ${res.status}).`);
      } else if (!data) {
        setError('Analysis failed — the server returned an empty response.');
      } else if (data.error) {
        setError(data.error);
      } else if (!data.summary || !Array.isArray(data.people)) {
        // Guard against a malformed/partial response shape so the UI never
        // tries to render a result object that's missing the fields it needs.
        setError('Analysis failed — received an unexpected response from the server.');
      } else {
        setResult(data);
      }
    } catch (e) {
      setError('Analysis failed — is the backend running?');
    } finally {
      setAnalyzing(false);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault(); setDragOver(false);
    const f = e.dataTransfer.files?.[0];
    if (f) handleFile(f);
  };

  const filteredPeople = result?.people.filter(p => p.confidence >= confFilter) ?? [];

  const exportCSV = () => {
    if (!result) return;
    const rows = [
      ['Type','Name/ID','Confidence','Detection Conf','Match Source','Previously Seen','Cross-Video','Timestamp'],
      ...result.people.map(p => [
        p.type, p.type === 'known' ? `${p.name} (${p.employeeId})` : p.unknownId,
        p.confidence, p.detectionConfidence, p.matchSource,
        p.previouslySeen ? 'Yes' : 'No', p.crossVideoMatch ? 'Yes' : 'No', p.timestamp,
      ]),
    ];
    const csv = rows.map(r => r.join(',')).join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = `image-analysis-${Date.now()}.csv`;
    a.click();
  };

  const exportPDF = () => {
    if (!result) return;
    // Opens a print-formatted view — user's browser "Save as PDF" produces
    // a genuine PDF without requiring a server-side PDF renderer.
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write(`
      <html><head><title>Image Analysis Report</title>
      <style>
        body{font-family:Arial,sans-serif;padding:32px;color:#111}
        h1{font-size:20px} h2{font-size:15px;margin-top:24px}
        table{width:100%;border-collapse:collapse;margin-top:8px}
        td,th{border:1px solid #ccc;padding:6px 10px;font-size:12px;text-align:left}
        .known{color:#0a8a4a} .unknown{color:#c2740c}
      </style></head><body>
        <h1>RedRuby — Image Analysis Report</h1>
        <p>Generated: ${result.timestamp}</p>
        <h2>Summary</h2>
        <p>${result.aiSummaryText}</p>
        <table>
          <tr><th>Total Persons</th><td>${result.summary.totalPersons}</td></tr>
          <tr><th>Known Employees</th><td>${result.summary.knownCount}</td></tr>
          <tr><th>Unknown Persons</th><td>${result.summary.unknownCount}</td></tr>
          <tr><th>Avg Detection Confidence</th><td>${result.summary.avgDetectionConfidence}%</td></tr>
          <tr><th>Avg Face Confidence</th><td>${result.summary.avgFaceConfidence}%</td></tr>
          <tr><th>Avg ReID Confidence</th><td>${result.summary.avgReidConfidence}%</td></tr>
          <tr><th>Processing Time</th><td>${result.summary.processingTimeMs}ms</td></tr>
          <tr><th>Detection Model</th><td>${result.summary.models.detection}</td></tr>
          <tr><th>Face Model</th><td>${result.summary.models.faceRecognition}</td></tr>
          <tr><th>ReID Model</th><td>${result.summary.models.reid}</td></tr>
        </table>
        <h2>Detected Persons</h2>
        <table>
          <tr><th>Type</th><th>Identity</th><th>Confidence</th><th>Previously Seen</th><th>Cross-Video</th></tr>
          ${result.people.map(p => `<tr>
            <td class="${p.type}">${p.type}</td>
            <td>${p.type === 'known' ? `${p.name} (${p.employeeId})` : p.unknownId}</td>
            <td>${p.confidence}%</td>
            <td>${p.previouslySeen ? 'Yes' : 'No'}</td>
            <td>${p.crossVideoMatch ? 'Yes' : 'No'}</td>
          </tr>`).join('')}
        </table>
      </body></html>
    `);
    w.document.close();
    w.print();
  };

  return (
    <div className="flex h-screen overflow-hidden bg-dark-900">
      <Sidebar />
      <main className="flex-1 ml-16 lg:ml-56 overflow-y-auto">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-dark-800/80 backdrop-blur border-b border-border px-6 py-3 flex items-center justify-between">
          <div>
            <h1 className="text-sm font-bold text-text-primary flex items-center gap-2">
              <ImagePlus className="w-4 h-4 text-accent" />Image Analysis
            </h1>
            <p className="text-[10px] text-text-muted">Upload a single photo — same detection, face, and ReID pipeline as live video</p>
          </div>
          {result && (
            <div className="flex items-center gap-2">
              <button onClick={exportCSV}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-dark-600 hover:bg-dark-500 border border-border text-text-secondary hover:text-text-primary rounded-xl text-xs font-bold transition-all">
                <Download className="w-3 h-3" />CSV
              </button>
              <button onClick={exportPDF}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-dark-600 hover:bg-dark-500 border border-border text-text-secondary hover:text-text-primary rounded-xl text-xs font-bold transition-all">
                <FileText className="w-3 h-3" />PDF
              </button>
              <button onClick={reset}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-red/10 hover:bg-red/20 border border-red/30 text-red rounded-xl text-xs font-bold transition-all">
                <X className="w-3 h-3" />Clear
              </button>
            </div>
          )}
        </header>

        <div className="p-6 space-y-6">

          {/* ── Upload zone (shown until a file is picked) ── */}
          {!file && (
            <div
              onDragOver={e => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={onDrop}
              onClick={() => fileRef.current?.click()}
              className={`glass-card rounded-2xl border-2 border-dashed p-16 flex flex-col items-center justify-center gap-4 cursor-pointer transition-all
                ${dragOver ? 'border-accent bg-accent/5' : 'border-border hover:border-accent/40'}`}>
              <div className="w-16 h-16 rounded-2xl bg-accent/10 border border-accent/20 flex items-center justify-center">
                <Upload className="w-7 h-7 text-accent" />
              </div>
              <div className="text-center">
                <p className="text-sm font-bold text-text-primary">Drop an image here, or click to browse</p>
                <p className="text-xs text-text-muted mt-1">Supports JPG, JPEG, PNG</p>
              </div>
              <input ref={fileRef} type="file" accept="image/jpeg,image/jpg,image/png" className="hidden"
                onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); }} />
            </div>
          )}

          {error && (
            <div className="glass-card rounded-2xl p-4 border border-red/30 bg-red/5 flex items-center gap-3">
              <AlertTriangle className="w-4 h-4 text-red flex-shrink-0" />
              <p className="text-xs text-red font-semibold">{error}</p>
            </div>
          )}

          {/* ── Preview + Analyze button (before analysis) ── */}
          {file && !result && (
            <div className="glass-card rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-xs font-bold text-text-primary truncate">{file.name}</p>
                <button onClick={reset} className="text-text-muted hover:text-red transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="rounded-xl overflow-hidden bg-dark-900 border border-border flex items-center justify-center max-h-96">
                {previewUrl && <img src={previewUrl} alt="preview" className="max-h-96 w-auto object-contain" />}
              </div>
              <button onClick={analyze} disabled={analyzing}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-accent hover:bg-accent-hover text-white rounded-xl text-sm font-bold transition-all disabled:opacity-50">
                {analyzing
                  ? <><Loader className="w-4 h-4 animate-spin" />Analyzing image...</>
                  : <><Sparkles className="w-4 h-4" />Run AI Analysis</>}
              </button>
            </div>
          )}

          {/* ── Results ── */}
          {result && (
            <>
              {/* Summary stat cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Total Persons',  val: result.summary.totalPersons, icon: <Eye className="w-4 h-4" />, color: 'text-accent' },
                  { label: 'Known Employees', val: result.summary.knownCount,  icon: <UserCheck className="w-4 h-4" />, color: 'text-green' },
                  { label: 'Unknown Persons', val: result.summary.unknownCount, icon: <UserX className="w-4 h-4" />, color: 'text-orange' },
                  { label: 'Processing Time', val: `${result.summary.processingTimeMs}ms`, icon: <Clock className="w-4 h-4" />, color: 'text-purple' },
                ].map((s, i) => (
                  <div key={i} className="glass-card rounded-2xl p-4">
                    <div className={`flex items-center gap-2 mb-2 ${s.color}`}>{s.icon}<span className="text-[10px] font-bold uppercase tracking-wider text-text-muted">{s.label}</span></div>
                    <p className="text-2xl font-black text-text-primary">{s.val}</p>
                  </div>
                ))}
              </div>

              {/* Confidence breakdown */}
              <div className="glass-card rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Gauge className="w-4 h-4 text-accent" />
                  <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider">Confidence Breakdown</h3>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  {[
                    { label: 'Detection', val: result.summary.avgDetectionConfidence, color: 'bg-accent' },
                    { label: 'Face Recognition', val: result.summary.avgFaceConfidence, color: 'bg-green' },
                    { label: 'ReID', val: result.summary.avgReidConfidence, color: 'bg-purple' },
                  ].map((c, i) => (
                    <div key={i}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-text-secondary font-semibold">{c.label}</span>
                        <span className="text-text-primary font-bold">{c.val}%</span>
                      </div>
                      <div className="h-1.5 bg-dark-600 rounded-full overflow-hidden">
                        <div className={`h-full ${c.color} rounded-full transition-all`} style={{ width: `${c.val}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex flex-wrap gap-3 mt-4 pt-4 border-t border-border text-[10px] text-text-muted">
                  <span>Detection: <span className="font-mono text-text-secondary">{result.summary.models.detection}</span></span>
                  <span>•</span>
                  <span>Face: <span className="font-mono text-text-secondary">{result.summary.models.faceRecognition}</span></span>
                  <span>•</span>
                  <span>ReID: <span className="font-mono text-text-secondary">{result.summary.models.reid}</span></span>
                  <span>•</span>
                  <span>{result.summary.imageWidth}×{result.summary.imageHeight}px</span>
                </div>
              </div>

              {/* AI Summary */}
              <div className="glass-card rounded-2xl p-5 border border-accent/20 bg-accent/5">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-4 h-4 text-accent" />
                  <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider">AI-Generated Summary</h3>
                </div>
                <p className="text-sm text-text-secondary leading-relaxed">{result.aiSummaryText}</p>
              </div>

              {/* Annotated image viewer */}
              <div className={`glass-card rounded-2xl overflow-hidden ${fullscreen ? 'fixed inset-4 z-50 flex flex-col' : ''}`}>
                <div className="flex items-center justify-between px-4 py-2.5 border-b border-border">
                  <span className="text-xs font-bold text-text-primary">Annotated Image</span>
                  <div className="flex items-center gap-1.5">
                    <button onClick={() => setShowBoxes(v => !v)}
                      className={`p-1.5 rounded-lg transition-all ${showBoxes ? 'bg-accent/20 text-accent' : 'text-text-muted hover:text-text-primary'}`} title="Toggle bounding boxes">
                      {showBoxes ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                    </button>
                    <button onClick={() => setZoom(z => Math.max(0.5, z - 0.25))} className="p-1.5 text-text-muted hover:text-text-primary rounded-lg" title="Zoom out">
                      <ZoomOut className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-[10px] font-mono text-text-muted w-10 text-center">{Math.round(zoom * 100)}%</span>
                    <button onClick={() => setZoom(z => Math.min(3, z + 0.25))} className="p-1.5 text-text-muted hover:text-text-primary rounded-lg" title="Zoom in">
                      <ZoomIn className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => setFullscreen(f => !f)} className="p-1.5 text-text-muted hover:text-text-primary rounded-lg">
                      {fullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                    </button>
                    <a href={result.annotatedImageUrl} download className="p-1.5 text-text-muted hover:text-accent rounded-lg" title="Save annotated image">
                      <Download className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
                <div className={`relative bg-dark-900 overflow-auto flex items-center justify-center ${fullscreen ? 'flex-1' : 'max-h-[500px]'}`}>
                  <img
                    src={showBoxes ? result.annotatedImageUrl : (previewUrl ?? result.annotatedImageUrl)}
                    alt="analysis"
                    style={{ transform: `scale(${zoom})`, transformOrigin: 'center center' }}
                    className="max-w-full h-auto object-contain transition-transform"
                  />
                </div>
              </div>

              {/* Confidence filter */}
              <div className="glass-card rounded-2xl p-4 flex items-center gap-4">
                <Tag className="w-4 h-4 text-text-muted flex-shrink-0" />
                <span className="text-xs font-semibold text-text-secondary whitespace-nowrap">Min confidence: {confFilter}%</span>
                <input type="range" min={0} max={100} step={5} value={confFilter}
                  onChange={e => setConfFilter(Number(e.target.value))}
                  className="flex-1 h-1.5 bg-dark-600 rounded-full appearance-none cursor-pointer accent-accent" />
                <span className="text-[10px] text-text-muted whitespace-nowrap">{filteredPeople.length} / {result.people.length} shown</span>
              </div>

              {/* Per-person cards */}
              <div className="glass-card rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Eye className="w-4 h-4 text-accent" />
                  <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider">Detected Persons</h3>
                  <span className="ml-auto text-[10px] font-bold bg-accent/10 text-accent px-2 py-0.5 rounded-full">{filteredPeople.length}</span>
                </div>

                {filteredPeople.length === 0 ? (
                  <div className="flex flex-col items-center gap-2 py-10 text-text-muted">
                    <ImageOff className="w-8 h-8 opacity-30" />
                    <p className="text-xs">No persons match this confidence filter.</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredPeople.map((p, i) => {
                      const key = p.unknownId ?? p.employeeId ?? String(i);
                      const isExpanded = expandedId === key;
                      const isKnown = p.type === 'known';
                      return (
                        <div key={key} className={`rounded-xl border overflow-hidden ${isKnown ? 'border-green/15' : 'border-orange/15'}`}>
                          <button onClick={() => setExpandedId(isExpanded ? null : key)}
                            className="w-full flex items-center gap-3 p-3 bg-dark-700 hover:bg-dark-600/60 transition-all text-left">
                            {isExpanded ? <ChevronDown className="w-3.5 h-3.5 text-text-muted flex-shrink-0" /> : <ChevronRight className="w-3.5 h-3.5 text-text-muted flex-shrink-0" />}
                            {p.snapshotUrl
                              ? <img src={p.snapshotUrl} alt="" className={`w-10 h-10 rounded-lg object-cover border flex-shrink-0 ${isKnown ? 'border-green/30' : 'border-orange/30'}`} onError={e => (e.currentTarget.style.display = 'none')} />
                              : <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${isKnown ? 'bg-green/10' : 'bg-orange/10'}`}>
                                  {isKnown ? <UserCheck className="w-4 h-4 text-green" /> : <UserX className="w-4 h-4 text-orange" />}
                                </div>}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <p className="text-xs font-bold text-text-primary truncate">{isKnown ? p.name : p.unknownId}</p>
                                {p.previouslySeen && (
                                  <span className="text-[9px] font-bold bg-purple/10 text-purple px-1.5 py-0.5 rounded-full flex-shrink-0">Previously Seen</span>
                                )}
                                {p.crossVideoMatch && (
                                  <span className="flex items-center gap-1 text-[9px] font-bold bg-accent/10 text-accent px-1.5 py-0.5 rounded-full flex-shrink-0">
                                    <GitCompare className="w-2.5 h-2.5" />Cross-Video
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] text-text-muted">
                                {isKnown ? p.employeeId : `Match source: ${p.matchSource}`} • {p.confidence}% confidence
                              </p>
                            </div>
                            <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full flex-shrink-0 ${isKnown ? 'bg-green/10 text-green' : 'bg-orange/10 text-orange'}`}>
                              {isKnown ? 'Known' : 'Unknown'}
                            </span>
                          </button>

                          {isExpanded && (
                            <div className="p-4 bg-dark-800 grid grid-cols-1 md:grid-cols-3 gap-4">
                              <div>
                                <p className="text-[9px] font-bold text-text-muted uppercase tracking-wider mb-2">Face / Profile Crop</p>
                                {p.snapshotUrl
                                  ? <img src={p.snapshotUrl} alt="" className="w-full h-32 object-cover rounded-xl border border-border" onError={e => (e.currentTarget.style.display = 'none')} />
                                  : <div className="w-full h-32 rounded-xl border border-border bg-dark-700 flex items-center justify-center text-text-muted text-xs">No face detected</div>}
                                <a href={p.snapshotUrl} download className="mt-2 flex items-center justify-center gap-1.5 text-[10px] font-bold text-accent hover:text-accent-hover">
                                  <Download className="w-3 h-3" />Download crop
                                </a>
                              </div>
                              <div>
                                <p className="text-[9px] font-bold text-text-muted uppercase tracking-wider mb-2">Full Body Crop</p>
                                <img src={p.fullCropUrl} alt="" className="w-full h-32 object-cover rounded-xl border border-border" onError={e => (e.currentTarget.style.display = 'none')} />
                                <a href={p.fullCropUrl} download className="mt-2 flex items-center justify-center gap-1.5 text-[10px] font-bold text-accent hover:text-accent-hover">
                                  <Download className="w-3 h-3" />Download crop
                                </a>
                              </div>
                              <div>
                                <p className="text-[9px] font-bold text-text-muted uppercase tracking-wider mb-2">Details</p>
                                <div className="bg-dark-700 border border-border rounded-xl p-3 space-y-1.5 text-[11px]">
                                  <div className="flex justify-between"><span className="text-text-muted">Type</span><span className="font-bold text-text-primary">{p.type}</span></div>
                                  <div className="flex justify-between"><span className="text-text-muted">Confidence</span><span className="font-bold text-text-primary">{p.confidence}%</span></div>
                                  <div className="flex justify-between"><span className="text-text-muted">Detection Conf.</span><span className="font-bold text-text-primary">{p.detectionConfidence}%</span></div>
                                  <div className="flex justify-between"><span className="text-text-muted">Face Detected</span><span className="font-bold text-text-primary">{p.hasFace ? 'Yes' : 'No'}</span></div>
                                  <div className="flex justify-between"><span className="text-text-muted">Timestamp</span><span className="font-bold text-text-primary">{p.timestamp}</span></div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
