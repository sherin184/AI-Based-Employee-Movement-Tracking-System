import { useState, useEffect } from 'react';
import Sidebar from '../components/Sidebar';
import { useTracking } from '../data/index';
import { Settings, Shield, Server, Trash2, RotateCcw, CheckCircle, Sliders, Database, Download, Info } from 'lucide-react';

export function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!value)}
      className={`relative w-10 h-5 rounded-full transition-all ${value ? 'bg-accent' : 'bg-dark-600 border border-border'}`}>
      <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${value ? 'left-5' : 'left-0.5'}`} />
    </button>
  );
}

function Slider({ label, value, min, max, step, onChange, unit = '' }:
  { label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void; unit?: string }) {
  return (
    <div>
      <div className="flex justify-between mb-1.5">
        <span className="text-xs text-text-secondary font-semibold">{label}</span>
        <span className="text-xs font-mono font-bold text-accent">{value}{unit}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="w-full h-1.5 bg-dark-600 rounded-full appearance-none cursor-pointer accent-accent" />
      <div className="flex justify-between text-[9px] text-text-muted mt-1">
        <span>{min}{unit}</span><span>{max}{unit}</span>
      </div>
    </div>
  );
}

export default function SettingsPage() {
  const { settings, saveSettings, resetDashboard, employees, unknowns, events } = useTracking();
  const [local, setLocal]     = useState<Record<string, any>>({});
  const [saved,  setSaved]    = useState(false);
  const [resetting, setReset] = useState(false);
  const [resetDone, setResetDone] = useState(false);
  const [activeSection, setActiveSection] = useState('detection');

  useEffect(() => { if (Object.keys(settings).length) setLocal({ ...settings }); }, [settings]);

  const set = (k: string, v: any) => setLocal(p => ({ ...p, [k]: v }));

  const handleSave = async () => {
    await saveSettings({
      yolo_confidence:   local.yolo_confidence,
      face_confidence:   local.face_confidence,
      reid_threshold:    local.reid_threshold,
      unknown_threshold: local.unknown_threshold,
      process_every_n:   local.process_every_n,
      bytetrack_buffer:  local.bytetrack_buffer,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const handleReset = async () => {
    setReset(true);
    await resetDashboard();
    setReset(false);
    setResetDone(true);
    setTimeout(() => setResetDone(false), 3000);
  };

  const sections = [
    { id: 'detection',  label: 'Detection',  icon: Sliders },
    { id: 'tracking',   label: 'Tracking',   icon: Settings },
    { id: 'database',   label: 'Database',   icon: Database },
    { id: 'system',     label: 'System',     icon: Server },
  ];

  return (
    <div className="flex h-screen overflow-hidden bg-dark-900">
      <Sidebar />
      <main className="flex-1 ml-16 lg:ml-56 overflow-y-auto">
        <header className="sticky top-0 z-40 bg-dark-800/80 backdrop-blur border-b border-border px-6 py-3 flex items-center justify-between">
          <div>
            <h1 className="text-sm font-bold text-text-primary">Settings</h1>
            <p className="text-[10px] text-text-muted">Configure detection, tracking and system parameters</p>
          </div>
          <button onClick={handleSave}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${saved ? 'bg-green/20 text-green border border-green/30' : 'bg-accent hover:bg-accent-hover text-white'}`}>
            {saved ? <><CheckCircle className="w-3.5 h-3.5" />Saved</> : <><Settings className="w-3.5 h-3.5" />Save Changes</>}
          </button>
        </header>

        <div className="p-6 flex gap-6">
          {/* Section nav */}
          <div className="w-44 flex-shrink-0 space-y-1">
            {sections.map(s => {
              const Icon = s.icon;
              return (
                <button key={s.id} onClick={() => setActiveSection(s.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left ${activeSection === s.id ? 'bg-accent/20 text-accent' : 'text-text-secondary hover:bg-dark-700 hover:text-text-primary'}`}>
                  <Icon className="w-3.5 h-3.5 flex-shrink-0" />{s.label}
                </button>
              );
            })}
          </div>

          {/* Content */}
          <div className="flex-1 space-y-5 max-w-2xl">

            {activeSection === 'detection' && (
              <>
                <div className="glass-card rounded-2xl p-6 space-y-6">
                  <div className="flex items-center gap-2 pb-3 border-b border-border">
                    <Sliders className="w-4 h-4 text-accent" />
                    <h2 className="text-sm font-bold text-text-primary">Detection Parameters</h2>
                  </div>

                  <Slider label="YOLO Detection Confidence" value={local.yolo_confidence ?? 0.25}
                    min={0.1} max={0.9} step={0.05} unit="" onChange={v => set('yolo_confidence', v)} />

                  <Slider label="Face Recognition Threshold" value={local.face_confidence ?? 0.35}
                    min={0.1} max={0.9} step={0.05} unit="" onChange={v => set('face_confidence', v)} />

                  <Slider label="ReID Similarity Threshold (Employees)" value={local.reid_threshold ?? 0.55}
                    min={0.1} max={0.95} step={0.05} unit="" onChange={v => set('reid_threshold', v)} />

                  <Slider label="ReID Similarity Threshold (Unknown)" value={local.unknown_threshold ?? 0.58}
                    min={0.1} max={0.95} step={0.05} unit="" onChange={v => set('unknown_threshold', v)} />

                  <div className="bg-dark-700 border border-border rounded-xl p-3 text-[10px] text-text-muted leading-relaxed">
                    <Info className="w-3 h-3 inline mr-1 text-accent" />
                    Lower thresholds detect more people but may cause false matches. Higher thresholds are stricter but may miss some identifications. Recommended: Face 0.35, ReID Employee 0.55, ReID Unknown 0.58.
                  </div>
                </div>

                <div className="glass-card rounded-2xl p-6 space-y-6">
                  <div className="flex items-center gap-2 pb-3 border-b border-border">
                    <Server className="w-4 h-4 text-accent" />
                    <h2 className="text-sm font-bold text-text-primary">Performance</h2>
                  </div>
                  <Slider label="Process Every N Frames" value={local.process_every_n ?? 3}
                    min={1} max={10} step={1} onChange={v => set('process_every_n', v)} />
                  <div className="bg-dark-700 border border-border rounded-xl p-3 text-[10px] text-text-muted">
                    <Info className="w-3 h-3 inline mr-1 text-accent" />
                    1 = every frame (most accurate, slowest). 5 = every 5th frame (balanced). 10 = fastest but may miss brief appearances.
                  </div>
                </div>
              </>
            )}

            {activeSection === 'tracking' && (
              <div className="glass-card rounded-2xl p-6 space-y-6">
                <div className="flex items-center gap-2 pb-3 border-b border-border">
                  <Settings className="w-4 h-4 text-accent" />
                  <h2 className="text-sm font-bold text-text-primary">ByteTrack Parameters</h2>
                </div>

                <Slider label="Lost Track Buffer (frames)" value={local.bytetrack_buffer ?? 60}
                  min={10} max={200} step={10} onChange={v => set('bytetrack_buffer', v)} />

                <div className="bg-dark-700 border border-border rounded-xl p-3 text-[10px] text-text-muted">
                  <Info className="w-3 h-3 inline mr-1 text-accent" />
                  Higher buffer = person keeps their track ID longer after leaving frame. Recommended 60–120 for indoor cameras.
                </div>

                <div className="pt-3 border-t border-border">
                  <h3 className="text-xs font-bold text-text-primary mb-3">Current Model Info</h3>
                  <div className="space-y-2">
                    {[
                      ['YOLO Model',     local.yolo_model  ?? 'yolo11n.pt'],
                      ['ReID Model',     local.reid_model  ?? 'osnet_x0_25'],
                      ['Face Model',     'buffalo_l (InsightFace)'],
                      ['Tracker',        'ByteTrack (supervision)'],
                    ].map(([k, v]) => (
                      <div key={k} className="flex justify-between text-xs py-2 border-b border-border/40 last:border-0">
                        <span className="text-text-muted font-semibold">{k}</span>
                        <span className="font-mono text-accent">{v}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'database' && (
              <>
                {/* Session stats */}
                <div className="glass-card rounded-2xl p-6">
                  <div className="flex items-center gap-2 pb-3 border-b border-border mb-4">
                    <Database className="w-4 h-4 text-accent" />
                    <h2 className="text-sm font-bold text-text-primary">Current Session</h2>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { label: 'Known Persons',   val: employees.length, color: 'text-green'  },
                      { label: 'Unknown Persons', val: unknowns.length,  color: 'text-orange' },
                      { label: 'Total Events',    val: events.length,    color: 'text-accent' },
                    ].map(s => (
                      <div key={s.label} className="bg-dark-700 border border-border rounded-xl p-4 text-center">
                        <p className={`text-2xl font-black ${s.color}`}>{s.val}</p>
                        <p className="text-[10px] text-text-muted mt-1 font-semibold">{s.label}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Reset */}
                <div className="glass-card rounded-2xl p-6">
                  <div className="flex items-center gap-2 pb-3 border-b border-border mb-4">
                    <Trash2 className="w-4 h-4 text-red" />
                    <h2 className="text-sm font-bold text-text-primary">Reset Dashboard</h2>
                  </div>
                  <p className="text-xs text-text-muted mb-4">Clears all detected persons, unknown IDs, and events from the current session. Also resets the persistent <span className="font-mono text-accent">unknowns_db.json</span>. Employee enrollment data is NOT affected.</p>
                  {resetDone
                    ? <div className="flex items-center gap-2 text-green bg-green/10 border border-green/30 px-4 py-2.5 rounded-xl text-sm font-bold"><CheckCircle className="w-4 h-4"/>Reset complete!</div>
                    : <button onClick={handleReset} disabled={resetting}
                        className="flex items-center gap-2 px-5 py-2.5 bg-red/20 hover:bg-red/30 border border-red/30 text-red rounded-xl text-sm font-bold transition-all disabled:opacity-50">
                        <RotateCcw className={`w-4 h-4 ${resetting ? 'animate-spin' : ''}`} />
                        {resetting ? 'Resetting...' : 'Clear All Detection Data'}
                      </button>}
                </div>

                {/* Export */}
                <div className="glass-card rounded-2xl p-6">
                  <div className="flex items-center gap-2 pb-3 border-b border-border mb-4">
                    <Download className="w-4 h-4 text-accent" />
                    <h2 className="text-sm font-bold text-text-primary">Export Data</h2>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: 'Export CSV',  fmt: 'csv'  },
                      { label: 'Export JSON', fmt: 'json' },
                    ].map(({ label, fmt }) => (
                      <button key={fmt} onClick={() => {
                        if (fmt === 'csv') {
                          const rows = [['Type','ID','Name','Confidence','First Seen','Last Seen','Detections'],
                            ...employees.map(e => ['Known',e.employeeId,e.name,e.confidence,e.firstSeen,e.lastSeen,e.detectionCount]),
                            ...unknowns.map(u  => ['Unknown',u.unknownId,'—',u.confidence,u.firstSeen,u.lastSeen,u.detectionCount])];
                          const a = document.createElement('a');
                          a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(rows.map(r=>r.join(',')).join('\n'));
                          a.download = `redruby-${Date.now()}.csv`; a.click();
                        } else {
                          const a = document.createElement('a');
                          a.href = 'data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify({employees,unknowns,events,exportedAt:new Date().toISOString()},null,2));
                          a.download = `redruby-${Date.now()}.json`; a.click();
                        }
                      }} className="flex items-center justify-center gap-2 px-4 py-2.5 bg-dark-700 hover:bg-dark-600 border border-border text-text-secondary hover:text-text-primary rounded-xl text-xs font-bold transition-all">
                        <Download className="w-3.5 h-3.5"/>{label}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {activeSection === 'system' && (
              <>
                <div className="glass-card rounded-2xl p-6">
                  <div className="flex items-center gap-2 pb-3 border-b border-border mb-4">
                    <Server className="w-4 h-4 text-accent" />
                    <h2 className="text-sm font-bold text-text-primary">System Information</h2>
                  </div>
                  <div className="space-y-2">
                    {[
                      ['Backend URL',       'http://localhost:8003'],
                      ['Detection Model',   'YOLOv11n — Person Detection'],
                      ['Tracker',           'ByteTrack (supervision)'],
                      ['Face Recognition',  'InsightFace buffalo_l'],
                      ['ReID Model',        'OSNet-x0.25 (torchreid)'],
                      ['Unknown Tracking',  'Persistent ReID gallery (unknowns_db.json)'],
                      ['Embedding Gallery', 'Up to 15 embeddings per person'],
                      ['ID Persistence',    'Cosine similarity ≥ threshold → same ID'],
                    ].map(([k,v]) => (
                      <div key={k} className="flex justify-between items-center py-2.5 border-b border-border/40 last:border-0">
                        <span className="text-xs font-bold text-text-muted uppercase tracking-wider">{k}</span>
                        <span className="font-mono text-[11px] text-text-secondary">{v}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="glass-card rounded-2xl p-6">
                  <div className="flex items-center gap-2 pb-3 border-b border-border mb-4">
                    <Shield className="w-4 h-4 text-green" />
                    <h2 className="text-sm font-bold text-text-primary">Add New Employee</h2>
                  </div>
                  <ol className="space-y-3 text-xs text-text-muted">
                    {[
                      <>Create a folder in <span className="font-mono bg-dark-700 px-1.5 py-0.5 rounded border border-border text-accent">backend/employees/</span> named <span className="font-mono bg-dark-700 px-1.5 py-0.5 rounded border border-border text-accent">EMPXXX_Name</span></>,
                      <>Add 2–3 clear, front-facing photos inside that folder</>,
                      <>Restart the backend — person is enrolled automatically on startup</>,
                      <>Upload a new video — they will now appear as <span className="text-green font-bold">Known</span></>,
                    ].map((step, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <span className="w-5 h-5 rounded-full bg-accent/20 text-accent flex items-center justify-center text-[10px] font-black flex-shrink-0 mt-0.5">{i+1}</span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              </>
            )}

          </div>
        </div>
      </main>
    </div>
  );
}
