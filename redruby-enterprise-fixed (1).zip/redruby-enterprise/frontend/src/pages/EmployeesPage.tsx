import React, { useState } from 'react';
import Sidebar from '../components/Sidebar';
import { useTracking } from '../data/index';
import { UserX, Search, ChevronDown, ChevronRight, Clock, Fingerprint, Activity, Download } from 'lucide-react';

export default function EmployeesPage() {
  const { employees, unknowns, events } = useTracking();
  const [search,    setSearch]    = useState('');
  const [filter,    setFilter]    = useState<'all'|'active'|'inactive'>('all');
  const [expandEmp, setExpandEmp] = useState<string|null>(null);
  const [expandUnk, setExpandUnk] = useState<string|null>(null);
  const [tab,       setTab]       = useState<'known'|'unknown'>('known');

  const filteredEmp = employees.filter(e => {
    const s = e.name.toLowerCase().includes(search.toLowerCase()) || e.employeeId.toLowerCase().includes(search.toLowerCase());
    const f = filter==='all' || e.status===filter;
    return s && f;
  });

  const filteredUnk = unknowns.filter(u =>
    u.unknownId.toLowerCase().includes(search.toLowerCase())
  );

  const total = employees.length + unknowns.length;
  const knownPct = total > 0 ? (employees.length/total)*100 : 0;
  const avgConf = employees.length > 0
    ? (employees.reduce((s,e)=>s+e.confidence,0)/employees.length).toFixed(1) : '0.0';
  const totalDet = employees.reduce((s,e)=>s+e.detectionCount,0)
    + unknowns.reduce((s,u)=>s+u.detectionCount,0);

  const exportCSV = () => {
    const rows = [
      ['Type','ID','Name','Confidence','First Seen','Last Seen','Detections'],
      ...employees.map(e=>['Known',e.employeeId,e.name,e.confidence,e.firstSeen,e.lastSeen,e.detectionCount]),
      ...unknowns.map(u=>['Unknown',u.unknownId,'—',u.confidence,u.firstSeen,u.lastSeen,u.detectionCount]),
    ];
    const csv = rows.map(r=>r.join(',')).join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = `redruby-analytics-${Date.now()}.csv`;
    a.click();
  };

  const exportJSON = () => {
    const data = { employees, unknowns, events, exportedAt: new Date().toISOString() };
    const a = document.createElement('a');
    a.href = 'data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(data, null, 2));
    a.download = `redruby-analytics-${Date.now()}.json`;
    a.click();
  };

  return (
    <div className="flex h-screen overflow-hidden bg-dark-900">
      <Sidebar />
      <main className="flex-1 ml-16 lg:ml-56 overflow-y-auto">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-dark-800/80 backdrop-blur border-b border-border px-6 py-3 flex items-center justify-between">
          <div>
            <h1 className="text-sm font-bold text-text-primary">Analytics & ReID Registry</h1>
            <p className="text-[10px] text-text-muted">Full tracking history with persistent identity management</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={exportCSV} className="flex items-center gap-1.5 px-3 py-1.5 bg-dark-600 hover:bg-dark-500 border border-border text-text-secondary hover:text-text-primary rounded-xl text-xs font-bold transition-all">
              <Download className="w-3 h-3"/>CSV
            </button>
            <button onClick={exportJSON} className="flex items-center gap-1.5 px-3 py-1.5 bg-dark-600 hover:bg-dark-500 border border-border text-text-secondary hover:text-text-primary rounded-xl text-xs font-bold transition-all">
              <Download className="w-3 h-3"/>JSON
            </button>
          </div>
        </header>

        <div className="p-6 space-y-6">
          {/* Metric cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label:'Known Profiles',    val:employees.length,       color:'text-accent',   bg:'bg-accent/10' },
              { label:'Unknown Profiles',  val:unknowns.length,        color:'text-orange',   bg:'bg-orange/10' },
              { label:'Total Detections',  val:totalDet,               color:'text-purple',   bg:'bg-purple/10' },
              { label:'Avg Confidence',    val:`${avgConf}%`,          color:'text-green',    bg:'bg-green/10'  },
            ].map((s,i)=>(
              <div key={i} className="glass-card rounded-2xl p-5">
                <p className={`text-2xl font-black ${s.color}`}>{s.val}</p>
                <p className="text-xs text-text-secondary font-semibold mt-1">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Charts row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Bar chart */}
            <div className="lg:col-span-2 glass-card rounded-2xl p-6">
              <div className="flex items-center gap-2 mb-5">
                <Activity className="w-4 h-4 text-accent" />
                <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider">Detection Activity per Person</h3>
              </div>
              <div className="h-36 flex items-end gap-2 border-b border-border/50">
                {[...employees, ...unknowns].length === 0
                  ? <p className="text-xs text-text-muted w-full text-center self-center">Upload a video to see activity</p>
                  : [...employees.map(e=>({label:e.name,count:e.detectionCount,known:true})),
                     ...unknowns.map(u=>({label:u.unknownId,count:u.detectionCount,known:false}))]
                    .sort((a,b)=>b.count-a.count).slice(0,10)
                    .map((item,i)=>{
                      const max = Math.max(...[...employees.map(e=>e.detectionCount),...unknowns.map(u=>u.detectionCount),1]);
                      const h = Math.max(6,(item.count/max)*100);
                      return (
                        <div key={i} className="flex-1 min-w-0 h-full flex flex-col justify-end items-center gap-1 group">
                          <span className="text-[9px] text-text-muted opacity-0 group-hover:opacity-100 font-mono">{item.count}</span>
                          <div className={`w-full rounded-t-md transition-all ${item.known?'bg-green/50 group-hover:bg-green':'bg-orange/50 group-hover:bg-orange'}`} style={{height:`${h}%`}} />
                          <span className="text-[8px] text-text-muted truncate w-full text-center">{item.label}</span>
                        </div>
                      );
                    })}
              </div>
              <div className="flex items-center gap-4 mt-3">
                <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-green"/><span className="text-[10px] text-text-muted">Known ({employees.length})</span></div>
                <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-orange"/><span className="text-[10px] text-text-muted">Unknown ({unknowns.length})</span></div>
              </div>
            </div>

            {/* Donut */}
            <div className="glass-card rounded-2xl p-6 flex flex-col items-center justify-center gap-4">
              <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider">Known vs Unknown</h3>
              <div className="w-32 h-32 rounded-full flex items-center justify-center"
                style={{background: total>0 ? `conic-gradient(#10B981 0% ${knownPct}%, #F59E0B ${knownPct}% 100%)` : '#1A2332'}}>
                <div className="w-24 h-24 bg-dark-800 rounded-full flex flex-col items-center justify-center">
                  <span className="text-xl font-black text-text-primary">{total}</span>
                  <span className="text-[9px] text-text-muted">Total</span>
                </div>
              </div>
              <div className="flex gap-4 text-[10px]">
                <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-green"/><span className="text-text-muted">Known {employees.length}</span></div>
                <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-orange"/><span className="text-text-muted">Unknown {unknowns.length}</span></div>
              </div>
            </div>
          </div>

          {/* Tab switcher + search */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center bg-dark-700 border border-border rounded-xl p-1 gap-1">
              {(['known','unknown'] as const).map(t=>(
                <button key={t} onClick={()=>setTab(t)}
                  className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${tab===t?'bg-dark-500 text-text-primary':'text-text-muted hover:text-text-primary'}`}>
                  {t==='known'?`Known (${employees.length})`:`Unknown (${unknowns.length})`}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-text-muted absolute left-3 top-1/2 -translate-y-1/2"/>
                <input type="text" placeholder="Search..." value={search} onChange={e=>setSearch(e.target.value)}
                  className="bg-dark-700 border border-border text-xs font-semibold rounded-xl pl-8 pr-4 py-2 w-48 outline-none focus:border-accent/50 text-text-primary placeholder-text-muted"/>
              </div>
              {tab==='known' && (
                <div className="flex items-center bg-dark-700 border border-border rounded-xl p-1">
                  {(['all','active','inactive'] as const).map(f=>(
                    <button key={f} onClick={()=>setFilter(f)}
                      className={`px-3 py-1 text-[10px] font-bold rounded-lg transition-all ${filter===f?'bg-dark-500 text-text-primary':'text-text-muted'}`}>
                      {f}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Known table */}
          {tab==='known' && (
            <div className="glass-card rounded-2xl overflow-hidden">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-dark-700 border-b border-border text-[10px] font-bold uppercase tracking-wider text-text-muted">
                    <th className="py-3 px-4 w-8"/>
                    <th className="py-3 px-4 text-left">Person</th>
                    <th className="py-3 px-4 text-left">Employee ID</th>
                    <th className="py-3 px-4 text-left">Confidence</th>
                    <th className="py-3 px-4 text-left">First Seen</th>
                    <th className="py-3 px-4 text-left">Last Seen</th>
                    <th className="py-3 px-4 text-left">Detections</th>
                    <th className="py-3 px-4 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {filteredEmp.length===0
                    ? <tr><td colSpan={8} className="py-12 text-center text-xs text-text-muted">No known persons detected. Upload a video to start.</td></tr>
                    : filteredEmp.map(emp=>{
                      const exp = expandEmp===emp.id;
                      return (
                        <React.Fragment key={emp.id}>
                          <tr onClick={()=>setExpandEmp(exp?null:emp.id)} className="hover:bg-dark-700/50 cursor-pointer transition-all">
                            <td className="py-3 px-4">{exp?<ChevronDown className="w-3.5 h-3.5 text-text-muted"/>:<ChevronRight className="w-3.5 h-3.5 text-text-muted"/>}</td>
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-3">
                                {emp.snapshotUrl
                                  ? <img src={emp.snapshotUrl} alt="" className="w-9 h-9 rounded-lg object-cover border border-border"/>
                                  : <div className="w-9 h-9 rounded-lg bg-green/10 border border-green/20 flex items-center justify-center text-[10px] font-bold text-green">{emp.name.slice(0,2).toUpperCase()}</div>}
                                <span className="text-xs font-bold text-text-primary">{emp.name}</span>
                              </div>
                            </td>
                            <td className="py-3 px-4 font-mono text-[11px] text-text-secondary">{emp.employeeId}</td>
                            <td className="py-3 px-4"><span className="font-mono font-bold text-green">{emp.confidence}%</span></td>
                            <td className="py-3 px-4 text-xs text-text-muted">{emp.firstSeen}</td>
                            <td className="py-3 px-4 text-xs text-text-muted">{emp.lastSeen}</td>
                            <td className="py-3 px-4 font-mono text-xs text-text-secondary">{emp.detectionCount}</td>
                            <td className="py-3 px-4 text-right">
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${emp.status==='active'?'bg-green/10 text-green':'bg-dark-600 text-text-muted'}`}>
                                {emp.status==='active'?'Active':'Away'}
                              </span>
                            </td>
                          </tr>
                          {exp && (
                            <tr className="bg-dark-800/50">
                              <td colSpan={8} className="p-6">
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                  {emp.snapshotUrl && (
                                    <div>
                                      <p className="text-[9px] font-bold text-text-muted uppercase tracking-wider mb-2">Latest Snapshot</p>
                                      <img src={emp.snapshotUrl} alt="" className="w-full h-40 object-cover rounded-xl border border-border"/>
                                    </div>
                                  )}
                                  <div>
                                    <p className="text-[9px] font-bold text-text-muted uppercase tracking-wider flex items-center gap-1 mb-2"><Clock className="w-3 h-3"/>Timeline</p>
                                    <div className="bg-dark-700 border border-border rounded-xl p-3 space-y-2">
                                      <div className="flex justify-between text-xs border-b border-border/50 pb-2"><span className="text-text-muted">First Spotted</span><span className="font-bold text-text-primary">{emp.firstSeen}</span></div>
                                      <div className="flex justify-between text-xs"><span className="text-text-muted">Last Logged</span><span className="font-bold text-text-primary">{emp.lastSeen}</span></div>
                                    </div>
                                  </div>
                                  <div>
                                    <p className="text-[9px] font-bold text-text-muted uppercase tracking-wider flex items-center gap-1 mb-2"><Fingerprint className="w-3 h-3"/>Detection Data</p>
                                    <div className="bg-dark-700 border border-border rounded-xl p-3 space-y-2">
                                      <div className="flex justify-between text-xs border-b border-border/50 pb-2"><span className="text-text-muted">Track ID</span><span className="font-mono font-bold text-accent">{emp.trackId}</span></div>
                                      <div className="flex justify-between text-xs"><span className="text-text-muted">Detections</span><span className="font-mono font-bold text-text-primary">{emp.detectionCount} frames</span></div>
                                    </div>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                </tbody>
              </table>
            </div>
          )}

          {/* Unknown table */}
          {tab==='unknown' && (
            <div className="glass-card rounded-2xl overflow-hidden border border-orange/10">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-orange/5 border-b border-orange/20 text-[10px] font-bold uppercase tracking-wider text-text-muted">
                    <th className="py-3 px-4 w-8"/>
                    <th className="py-3 px-4 text-left">Snapshot</th>
                    <th className="py-3 px-4 text-left">Assigned ID</th>
                    <th className="py-3 px-4 text-left">Track ID</th>
                    <th className="py-3 px-4 text-left">First Seen</th>
                    <th className="py-3 px-4 text-left">Last Seen</th>
                    <th className="py-3 px-4 text-left">Appearances</th>
                    <th className="py-3 px-4 text-right">Detections</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {filteredUnk.length===0
                    ? <tr><td colSpan={8} className="py-12 text-center text-xs text-text-muted">No unknown persons detected. Non-enrolled people will appear here.</td></tr>
                    : filteredUnk.map(unk=>{
                      const exp = expandUnk===unk.id;
                      return (
                        <React.Fragment key={unk.id}>
                          <tr onClick={()=>setExpandUnk(exp?null:unk.id)} className="hover:bg-orange/5 cursor-pointer transition-all">
                            <td className="py-3 px-4">{exp?<ChevronDown className="w-3.5 h-3.5 text-text-muted"/>:<ChevronRight className="w-3.5 h-3.5 text-text-muted"/>}</td>
                            <td className="py-3 px-4">
                              {unk.snapshotUrl
                                ? <img src={unk.snapshotUrl} alt="" className="w-10 h-10 rounded-lg object-cover border border-orange/20"/>
                                : <div className="w-10 h-10 rounded-lg bg-orange/10 border border-orange/20 flex items-center justify-center"><UserX className="w-4 h-4 text-orange"/></div>}
                            </td>
                            <td className="py-3 px-4 font-mono font-bold text-orange">{unk.unknownId}</td>
                            <td className="py-3 px-4 font-mono text-xs text-text-secondary">{unk.trackId}</td>
                            <td className="py-3 px-4 text-xs text-text-muted">{unk.firstSeen}</td>
                            <td className="py-3 px-4 text-xs text-text-muted">{unk.lastSeen}</td>
                            <td className="py-3 px-4 font-mono text-xs text-text-secondary">{unk.appearances}</td>
                            <td className="py-3 px-4 text-right font-mono text-xs text-text-secondary">{unk.detectionCount}</td>
                          </tr>
                          {exp && (
                            <tr className="bg-orange/5">
                              <td colSpan={8} className="p-6">
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                  {unk.snapshotUrl && (
                                    <div>
                                      <p className="text-[9px] font-bold text-text-muted uppercase tracking-wider mb-2">Latest Snapshot</p>
                                      <img src={unk.snapshotUrl} alt="" className="w-full h-44 object-cover rounded-xl border border-orange/20"/>
                                    </div>
                                  )}
                                  <div>
                                    <p className="text-[9px] font-bold text-text-muted uppercase tracking-wider flex items-center gap-1 mb-2"><Clock className="w-3 h-3"/>Timeline</p>
                                    <div className="bg-dark-700 border border-border rounded-xl p-3 space-y-2">
                                      <div className="flex justify-between text-xs border-b border-border/50 pb-2"><span className="text-text-muted">First Spotted</span><span className="font-bold text-text-primary">{unk.firstSeen}</span></div>
                                      <div className="flex justify-between text-xs pt-0.5"><span className="text-text-muted">Last Seen</span><span className="font-bold text-text-primary">{unk.lastSeen}</span></div>
                                    </div>
                                  </div>
                                  <div>
                                    <p className="text-[9px] font-bold text-text-muted uppercase tracking-wider flex items-center gap-1 mb-2"><Fingerprint className="w-3 h-3"/>Notes</p>
                                    <div className="bg-dark-700 border border-border rounded-xl p-3 text-xs text-text-secondary leading-relaxed">
                                      Person not matched to any enrolled employee. Their ID <span className="font-mono text-orange">{unk.unknownId}</span> is persistent across this session via ReID body embeddings. To identify, add photos to <span className="font-mono bg-dark-600 px-1 rounded">employees/</span> and restart.
                                    </div>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
