import React, { useRef, useMemo } from 'react';
import Sidebar from '../components/Sidebar';
import StatCard from '../components/StatCard';
import { useTracking } from '../data/index';
import type { UnknownPerson } from '../data/index';
import { Upload, VideoOff, UserX, Repeat, Wifi, WifiOff, Loader, Layers, ArrowLeftRight } from 'lucide-react';

interface VideoPanelProps {
  label: string;
  videoUrl: string | null;
  processing: { active:boolean; progress:number; fps:number; eta:string; video_name:string; processed:number; total_frames:number };
  onPick: () => void;
  accent: 'blue' | 'purple';
}

function VideoPanel({ label, videoUrl, processing, onPick, accent }: VideoPanelProps) {
  const ring = accent === 'blue' ? 'bg-accent' : 'bg-purple';
  return (
    <div className="glass-card rounded-2xl overflow-hidden flex flex-col">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${ring} animate-pulse`} />
          <span className="text-xs font-bold text-text-primary uppercase tracking-wider">{label}</span>
        </div>
        {processing.video_name && <span className="text-[10px] text-text-muted truncate max-w-[140px]">{processing.video_name}</span>}
      </div>
      <div className="relative bg-dark-900 aspect-video flex items-center justify-center overflow-hidden">
        {videoUrl ? (
          <video src={videoUrl} controls autoPlay loop muted className="w-full h-full object-cover" />
        ) : (
          <div className="flex flex-col items-center gap-3 text-center p-6">
            <VideoOff className="w-10 h-10 text-text-muted/30" />
            <p className="text-xs font-bold text-text-muted">No video loaded</p>
            <button onClick={onPick} className="mt-1 flex items-center gap-2 px-3 py-1.5 bg-accent/20 hover:bg-accent/30 border border-accent/30 text-accent rounded-xl text-[11px] font-bold transition-all">
              <Upload className="w-3 h-3" />Choose {label}
            </button>
          </div>
        )}
        {processing.active && (
          <div className="absolute bottom-0 left-0 right-0 bg-dark-900/85 px-3 py-2">
            <div className="flex justify-between text-[9px] text-text-muted mb-1">
              <span>{processing.progress}% • {processing.processed}/{processing.total_frames} frames</span>
              <span>ETA {processing.eta}</span>
            </div>
            <div className="h-1 bg-dark-600 rounded-full overflow-hidden">
              <div className={`h-full ${ring} transition-all rounded-full`} style={{ width: `${processing.progress}%` }} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function DualVideoPage() {
  const { unknowns, events, videoUrl1, videoUrl2, processing1, processing2, uploadDualVideos, isConnected } = useTracking();
  const file1Ref = useRef<HTMLInputElement>(null);
  const file2Ref = useRef<HTMLInputElement>(null);
  const pending1 = useRef<File | null>(null);
  const pending2 = useRef<File | null>(null);
  const [ready, setReady] = React.useState(false);

  const handlePick = (which: 1 | 2, f: File) => {
    if (which === 1) pending1.current = f; else pending2.current = f;
    setReady(!!pending1.current && !!pending2.current);
  };

  const handleRun = () => {
    if (pending1.current && pending2.current) uploadDualVideos(pending1.current, pending2.current);
  };

  // Cross-video re-identification table — one row per detection event,
  // exactly like: Video | Person | AssignedVideo
  const reidRows = useMemo(() => {
    const rows: { video: number; label: string; unknownId: string; reused: boolean }[] = [];
    const seenPerVideo = new Set<string>(); // `${videoId}:${unknownId}` — one row per first appearance on a video
    for (const ev of [...events].reverse()) {
      if (ev.type !== 'unknown' || !ev.unknownId || !ev.videoId) continue;
      const key = `${ev.videoId}:${ev.unknownId}`;
      if (seenPerVideo.has(key)) continue;
      seenPerVideo.add(key);
      rows.push({
        video: ev.videoId,
        label: ev.reusedAcrossVideos ? 'Re-appeared (matched)' : 'New person detected',
        unknownId: ev.unknownId,
        reused: !!ev.reusedAcrossVideos,
      });
    }
    return rows;
  }, [events]);

  const reusedPeople = useMemo(() => unknowns.filter((u: UnknownPerson) => u.reusedAcrossVideos), [unknowns]);

  return (
    <div className="flex h-screen overflow-hidden bg-dark-900">
      <Sidebar />
      <main className="flex-1 ml-16 lg:ml-56 overflow-y-auto">
        <header className="sticky top-0 z-40 bg-dark-800/80 backdrop-blur border-b border-border px-6 py-3 flex items-center justify-between">
          <div>
            <h1 className="text-sm font-bold text-text-primary">Dual Video Screen</h1>
            <p className="text-[10px] text-text-muted">Cross-camera re-identification — same unknown person, same UNK-id, across both feeds</p>
          </div>
          <div className="flex items-center gap-3">
            <div className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-[10px] font-bold ${isConnected ? 'bg-green/10 border-green/30 text-green' : 'bg-red/10 border-red/30 text-red'}`}>
              {isConnected ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
              {isConnected ? 'Connected' : 'Offline'}
            </div>
            <button
              onClick={handleRun}
              disabled={!ready}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${ready ? 'bg-accent hover:bg-accent-hover text-white' : 'bg-dark-600 text-text-muted cursor-not-allowed'}`}
            >
              <Layers className="w-3.5 h-3.5" />Run Detection
            </button>
          </div>
        </header>

        <div className="p-6 space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
            <StatCard label="Unknown Persons" value={unknowns.length} sub="Across both videos" icon={<UserX className="w-5 h-5" />} color="orange" />
            <StatCard label="Cross-Video Matches" value={reusedPeople.length} sub="Same person, reused UNK-id" icon={<Repeat className="w-5 h-5" />} color="purple" />
            <StatCard label="Video 1 Status" value={processing1.active ? `${processing1.progress}%` : (videoUrl1 ? 'Done' : 'Idle')} sub={processing1.active ? `${processing1.fps} FPS` : 'Upload to begin'} icon={<Loader className="w-5 h-5" />} color="blue" />
            <StatCard label="Video 2 Status" value={processing2.active ? `${processing2.progress}%` : (videoUrl2 ? 'Done' : 'Idle')} sub={processing2.active ? `${processing2.fps} FPS` : 'Upload to begin'} icon={<Loader className="w-5 h-5" />} color="purple" />
          </div>

          {/* Two video panels side by side */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <VideoPanel label="Video 1" videoUrl={videoUrl1} processing={processing1} accent="blue" onPick={() => file1Ref.current?.click()} />
            <VideoPanel label="Video 2" videoUrl={videoUrl2} processing={processing2} accent="purple" onPick={() => file2Ref.current?.click()} />
          </div>
          <input ref={file1Ref} type="file" accept="video/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handlePick(1, f); }} />
          <input ref={file2Ref} type="file" accept="video/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handlePick(2, f); }} />

          {!ready && !videoUrl1 && !videoUrl2 && (
            <p className="text-[10px] text-text-muted text-center -mt-3">Choose a video for each panel above, then hit <span className="text-accent font-bold">Run Detection</span>.</p>
          )}

          {/* Cross-video identity table */}
          <div className="glass-card rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <ArrowLeftRight className="w-4 h-4 text-purple" />
              <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider">Cross-Video Identity Table</h3>
              <span className="ml-auto text-[10px] font-bold bg-purple/10 text-purple px-2 py-0.5 rounded-full">{reidRows.length} rows</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="text-[10px] text-text-muted uppercase tracking-wider border-b border-border">
                    <th className="py-2 pr-4 font-bold">Video</th>
                    <th className="py-2 pr-4 font-bold">Person</th>
                    <th className="py-2 pr-4 font-bold">Assigned ID</th>
                  </tr>
                </thead>
                <tbody>
                  {reidRows.length === 0 ? (
                    <tr><td colSpan={3} className="py-6 text-center text-xs text-text-muted">No detections yet — run both videos to populate this table</td></tr>
                  ) : reidRows.map((r, i) => (
                    <tr key={i} className="border-b border-border/50 last:border-0">
                      <td className="py-2.5 pr-4">
                        <span className={`text-[10px] font-bold px-2 py-1 rounded-lg ${r.video === 1 ? 'bg-accent/10 text-accent' : 'bg-purple/10 text-purple'}`}>Video {r.video}</span>
                      </td>
                      <td className="py-2.5 pr-4 text-xs text-text-secondary">{r.label}</td>
                      <td className="py-2.5 pr-4">
                        <span className="text-xs font-bold text-orange">{r.unknownId}</span>
                        {r.reused && <span className="ml-2 text-[9px] font-bold bg-green/10 text-green px-1.5 py-0.5 rounded-full">reused!</span>}
                        {!r.reused && <span className="ml-2 text-[9px] font-bold bg-orange/10 text-orange px-1.5 py-0.5 rounded-full">new</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Unknown gallery with per-video badges */}
          <div className="glass-card rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <UserX className="w-4 h-4 text-orange" />
              <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider">Unknown Person Gallery</h3>
              <span className="ml-auto text-[10px] font-bold bg-orange/10 text-orange px-2 py-0.5 rounded-full">{unknowns.length}</span>
            </div>
            {unknowns.length === 0 ? (
              <p className="text-xs text-text-muted text-center py-4">No unknowns detected</p>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
                {unknowns.map((unk: UnknownPerson) => {
                  const byVideo = unk.snapshotsByVideo ?? {};
                  const shots = Object.entries(byVideo); // [["1", url], ["2", url]]
                  return (
                  <div key={unk.id} className={`flex items-center gap-3 bg-dark-700 rounded-xl p-2.5 border ${unk.reusedAcrossVideos ? 'border-green/30' : 'border-orange/10'}`}>
                    {shots.length > 0 ? (
                      <div className="flex -space-x-2 flex-shrink-0">
                        {shots.map(([vid, url]) => (
                          <img key={vid} src={url} alt="" title={`Video ${vid}`}
                            className={`w-10 h-10 rounded-lg object-cover border-2 ${vid === '1' ? 'border-accent' : 'border-purple'}`} />
                        ))}
                      </div>
                    ) : unk.snapshotUrl ? (
                      <img src={unk.snapshotUrl} alt="" className="w-10 h-10 rounded-lg object-cover border border-orange/20 flex-shrink-0" />
                    ) : (
                      <div className="w-10 h-10 rounded-lg bg-orange/10 flex items-center justify-center flex-shrink-0"><UserX className="w-4 h-4 text-orange" /></div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-orange truncate">{unk.unknownId}</p>
                      <div className="flex items-center gap-1 mt-0.5 flex-wrap">
                        {(unk.videos ?? []).map(v => (
                          <span key={v} className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${v === 1 ? 'bg-accent/10 text-accent' : 'bg-purple/10 text-purple'}`}>V{v}</span>
                        ))}
                        {unk.reusedAcrossVideos && <span className="text-[9px] font-bold bg-green/10 text-green px-1.5 py-0.5 rounded-full flex items-center gap-0.5"><Repeat className="w-2.5 h-2.5" />reused</span>}
                      </div>
                    </div>
                  </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
