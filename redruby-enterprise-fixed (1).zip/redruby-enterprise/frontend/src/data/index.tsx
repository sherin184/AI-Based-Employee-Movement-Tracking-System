import React, { createContext, useContext, useState, useEffect, useRef } from 'react';

export const API  = 'http://localhost:8003';
export const WS   = 'ws://localhost:8003/ws';

export interface Camera { id:string; name:string; location:string; status:string; fps:number; resolution:string; }
export interface Employee { id:string; employeeId:string; name:string; trackId:string; confidence:number; detectionCount:number; status:string; firstSeen:string; lastSeen:string; timeTracked:string; snapshotUrl?:string; videoId?:number; }
export interface UnknownPerson { id:string; unknownId:string; trackId:string; firstSeen:string; lastSeen:string; detectionCount:number; appearances:number; confidence:number; snapshotUrl?:string; status:string; videoId?:number; videos?:number[]; reusedAcrossVideos?:boolean; snapshotsByVideo?:Record<string,string>; }
export interface DetectionEvent { id:string; timestamp:string; employeeId:string|null; employeeName:string; cameraId:string; cameraName:string; confidence:number; type:'known'|'unknown'; snapshotUrl?:string; unknownId?:string; firstSeen?:string; lastSeen?:string; videoId?:number; reusedAcrossVideos?:boolean; }
export interface ProcessingStatus { active:boolean; progress:number; total_frames:number; processed:number; fps:number; eta:string; video_name:string; }

interface Ctx {
  cameras:Camera[]; activeCamera:Camera|null; setActiveCamera:(c:Camera)=>void;
  employees:Employee[]; unknowns:UnknownPerson[];
  events:DetectionEvent[]; videoUrl:string|null;
  processing:ProcessingStatus; isConnected:boolean; latestAlert:DetectionEvent|null;
  uploadVideo:(f:File)=>Promise<void>; resetDashboard:()=>Promise<void>;
  settings:Record<string,any>; loadSettings:()=>Promise<void>; saveSettings:(s:any)=>Promise<void>;
  // Dual-video screen
  videoUrl1:string|null; videoUrl2:string|null;
  processing1:ProcessingStatus; processing2:ProcessingStatus;
  uploadDualVideos:(f1:File,f2:File)=>Promise<void>;
}

const TrackingContext = createContext<Ctx|undefined>(undefined);

const DEFAULT_PROCESSING: ProcessingStatus = { active:false, progress:0, total_frames:0, processed:0, fps:0, eta:'', video_name:'' };

export const TrackingSystemProvider:React.FC<{children:React.ReactNode}> = ({children}) => {
  const [cameras,    setCameras]    = useState<Camera[]>([]);
  const [activeCamera, setActiveCamera] = useState<Camera|null>(null);
  const [employees,  setEmployees]  = useState<Employee[]>([]);
  const [unknowns,   setUnknowns]   = useState<UnknownPerson[]>([]);
  const [events,     setEvents]     = useState<DetectionEvent[]>([]);
  const [videoUrl,   setVideoUrl]   = useState<string|null>(null);
  const [processing, setProcessing] = useState<ProcessingStatus>(DEFAULT_PROCESSING);
  const [videoUrl1,  setVideoUrl1]  = useState<string|null>(null);
  const [videoUrl2,  setVideoUrl2]  = useState<string|null>(null);
  const [processing1,setProcessing1]= useState<ProcessingStatus>(DEFAULT_PROCESSING);
  const [processing2,setProcessing2]= useState<ProcessingStatus>(DEFAULT_PROCESSING);
  const [isConnected,setIsConnected]= useState(false);
  const [latestAlert,setLatestAlert]= useState<DetectionEvent|null>(null);
  const [settings,   setSettings]   = useState<Record<string,any>>({});
  const wsRef   = useRef<WebSocket|null>(null);
  const alertTo = useRef<ReturnType<typeof setTimeout>|null>(null);

  useEffect(() => {
    fetch(`${API}/cameras`).then(r=>r.json()).then((d:Camera[])=>{setCameras(d);if(d.length)setActiveCamera(d[0]);})
      .catch(()=>{ const f=[{id:'cam01',name:'Camera 01',location:'Main Entrance',status:'online',fps:25,resolution:'1280x720'}]; setCameras(f); setActiveCamera(f[0]); });
    loadSettings();
  }, []);

  useEffect(() => {
    const connect = () => {
      const ws = new WebSocket(WS); wsRef.current = ws;
      ws.onopen  = () => setIsConnected(true);
      ws.onclose = () => { setIsConnected(false); setTimeout(connect, 3000); };
      ws.onerror = () => ws.close();
      ws.onmessage = (e) => {
        try {
          const msg = JSON.parse(e.data);
          if (msg.type==='employee_update') setEmployees(msg.employees);
          if (msg.type==='unknown_update')  setUnknowns(msg.unknowns);
          if (msg.type==='processing_status') {
            const vid = msg.videoId ?? 1;
            if (vid===1) { setProcessing(msg.status); setProcessing1(msg.status); }
            else         { setProcessing2(msg.status); }
          }
          if (msg.type==='event_update') {
            const evs:DetectionEvent[] = Array.isArray(msg.events)?msg.events:[msg.events];
            if (!evs.length) { setEvents([]); return; }
            setEvents(prev => {
              const seen = new Set<string>();
              return [...evs,...prev].filter(ev=>{
                const k = ev.type==='known'?(ev.employeeId??ev.id):(ev.unknownId??ev.id);
                if(seen.has(k)) return false; seen.add(k); return true;
              }).slice(0,100);
            });
          }
          if (msg.type==='detection_alert') {
            setLatestAlert(msg.event);
            if(alertTo.current) clearTimeout(alertTo.current);
            alertTo.current = setTimeout(()=>setLatestAlert(null), 3000);
          }
        } catch {}
      };
    };
    connect();
    return () => wsRef.current?.close();
  }, []);

  const uploadVideo = async (file:File) => {
    setEmployees([]); setUnknowns([]); setEvents([]); setLatestAlert(null);
    setVideoUrl(URL.createObjectURL(file));
    setProcessing({...DEFAULT_PROCESSING, active:true, video_name:file.name});
    const fd = new FormData(); fd.append('file',file);
    await fetch(`${API}/upload-video`,{method:'POST',body:fd}).catch(()=>{});
  };

  const resetDashboard = async () => {
    setEmployees([]); setUnknowns([]); setEvents([]); setLatestAlert(null); setVideoUrl(null);
    setProcessing(DEFAULT_PROCESSING);
    setVideoUrl1(null); setVideoUrl2(null);
    setProcessing1(DEFAULT_PROCESSING); setProcessing2(DEFAULT_PROCESSING);
    await fetch(`${API}/reset`,{method:'POST'}).catch(()=>{});
  };

  const uploadDualVideos = async (file1:File, file2:File) => {
    setEmployees([]); setUnknowns([]); setEvents([]); setLatestAlert(null);
    setVideoUrl1(URL.createObjectURL(file1));
    setVideoUrl2(URL.createObjectURL(file2));
    setProcessing1({...DEFAULT_PROCESSING, active:true, video_name:file1.name});
    setProcessing2({...DEFAULT_PROCESSING, active:true, video_name:file2.name});
    const fd = new FormData(); fd.append('video1',file1); fd.append('video2',file2);
    await fetch(`${API}/upload-dual-video`,{method:'POST',body:fd}).catch(()=>{});
  };

  const loadSettings = async () => {
    try { const d = await fetch(`${API}/settings`).then(r=>r.json()); setSettings(d); } catch {}
  };

  const saveSettings = async (s:any) => {
    await fetch(`${API}/settings`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(s)}).catch(()=>{});
    await loadSettings();
  };

  return (
    <TrackingContext.Provider value={{cameras,activeCamera,setActiveCamera,employees,unknowns,events,videoUrl,processing,isConnected,latestAlert,uploadVideo,resetDashboard,settings,loadSettings,saveSettings,
      videoUrl1,videoUrl2,processing1,processing2,uploadDualVideos}}>
      {children}
    </TrackingContext.Provider>
  );
};

export const useTracking = () => {
  const ctx = useContext(TrackingContext);
  if(!ctx) throw new Error('useTracking must be inside TrackingSystemProvider');
  return ctx;
};
