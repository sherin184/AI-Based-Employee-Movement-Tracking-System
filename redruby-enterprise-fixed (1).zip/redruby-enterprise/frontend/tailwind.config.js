/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      colors: {
        dark:    { 900:'#080B0F', 800:'#0D1117', 700:'#131920', 600:'#1A2332', 500:'#1E2A3A', 400:'#243347' },
        accent:  { DEFAULT:'#3B82F6', hover:'#2563EB', glow:'rgba(59,130,246,0.3)' },
        green:   { DEFAULT:'#10B981', glow:'rgba(16,185,129,0.3)' },
        orange:  { DEFAULT:'#F59E0B', glow:'rgba(245,158,11,0.3)' },
        red:     { DEFAULT:'#EF4444', glow:'rgba(239,68,68,0.3)' },
        purple:  { DEFAULT:'#8B5CF6', glow:'rgba(139,92,246,0.3)' },
        border:  { DEFAULT:'rgba(255,255,255,0.06)', bright:'rgba(255,255,255,0.12)' },
        text:    { primary:'#F1F5F9', secondary:'#94A3B8', muted:'#475569' },
      },
      backgroundImage: {
        'glass':      'linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%)',
        'glass-card': 'linear-gradient(135deg, rgba(30,42,58,0.8) 0%, rgba(19,25,32,0.9) 100%)',
        'accent-glow':'linear-gradient(135deg, rgba(59,130,246,0.15) 0%, rgba(139,92,246,0.1) 100%)',
      },
      boxShadow: {
        'glass':  '0 8px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.06)',
        'card':   '0 4px 24px rgba(0,0,0,0.3), 0 1px 0 rgba(255,255,255,0.04)',
        'glow-b': '0 0 20px rgba(59,130,246,0.3)',
        'glow-g': '0 0 20px rgba(16,185,129,0.3)',
        'glow-o': '0 0 20px rgba(245,158,11,0.3)',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4,0,0.6,1) infinite',
        'fade-in':    'fadeIn 0.3s ease-out',
        'slide-up':   'slideUp 0.3s ease-out',
      },
      keyframes: {
        fadeIn:  { '0%':{ opacity:'0' }, '100%':{ opacity:'1' } },
        slideUp: { '0%':{ opacity:'0', transform:'translateY(8px)' }, '100%':{ opacity:'1', transform:'translateY(0)' } },
      },
    },
  },
  plugins: [],
}
