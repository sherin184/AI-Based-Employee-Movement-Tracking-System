# RedRuby Enterprise — AI Surveillance Dashboard

Production-ready AI surveillance system with persistent person tracking, face recognition, and ReID-based identity management.

## Quick Start

**Double-click `start.bat`** — starts both servers and opens the browser.

Or manually:
```powershell
# Terminal 1 — Backend
cd backend
uvicorn app:app --host 127.0.0.1 --port 8003

# Terminal 2 — Frontend
cd frontend
npm run dev
```

Open: `http://localhost:5173`

---

## Architecture

```
Video Upload
    ↓
YOLOv11 Person Detection (confidence tunable)
    ↓
ByteTrack Multi-Object Tracking (stable track IDs)
    ↓
InsightFace Face Recognition (primary ID)
    ↓
OSNet-x0.25 ReID Fallback (body embedding)
    ↓
Known Employee? → Named card + verified badge
Unknown Person? → UNK-N ID (persistent via ReID gallery)
    ↓
WebSocket broadcast → Dashboard updates live
```

## Key Features

- **Persistent Unknown IDs** — `UNK-1` stays `UNK-1` even if person leaves and re-enters frame. Rolling gallery of 15 embeddings + mean embedding for robust matching.
- **Face + ReID fusion** — face recognition when visible, body ReID as fallback. Identity never switches mid-track.
- **unknowns_db.json** — persists across backend restarts. Known IDs survive server reboots.
- **Dark enterprise UI** — glassmorphism cards, real-time processing progress bar, detection alerts, analytics page, export CSV/JSON.
- **Settings page** — all thresholds tunable live without restarting.

## Adding Employees

```
backend/employees/
├── EMP001_Name/
│   ├── photo1.jpg
│   └── photo2.jpg
└── EMP002_Name/
    └── photo1.jpg
```

Restart backend → person enrolled automatically.

## Tuning

| Parameter | Default | Notes |
|-----------|---------|-------|
| YOLO confidence | 0.25 | Lower = detect more people |
| Face threshold | 0.35 | Cosine similarity |
| ReID employee | 0.55 | Body match for known employees |
| ReID unknown | 0.58 | Body match for UNK reuse |
| ByteTrack buffer | 60 | Frames before track lost |
| Process every N | 3 | 1=every frame, 5=balanced |

All tunable live on the Settings page.
